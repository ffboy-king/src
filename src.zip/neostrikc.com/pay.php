<?php
$session_id = isset($_GET['sid']) ? trim($_GET['sid']) : '';
$order_id   = isset($_GET['oid']) ? trim($_GET['oid']) : '';

if (isset($_GET['success'])) {
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Payment Success</title>
    <style>body{font-family:sans-serif;background:#0d1117;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:20px}
    .box{background:#161b22;border-radius:16px;padding:30px;max-width:360px}h2{color:#2ea043}p{color:#8b949e;margin:10px 0 20px}
    a{display:block;background:#238636;color:#fff;text-decoration:none;padding:14px;border-radius:10px;font-weight:bold}</style></head>
    <body><div class="box"><div style="font-size:60px">✅</div><h2>Payment Successful!</h2>
    <p>Key Telegram pe bhej di gayi hai. Bot check karo!</p>
    <a href="https://t.me/NEO_STRIKE_BOT">🤖 Telegram Bot Pe Jao</a></div></body></html>';
    exit;
}

if (empty($session_id) || empty($order_id)) {
    die('<h2 style="color:red;text-align:center;padding:40px">Invalid link. Go back to bot.</h2>');
}

$return_url = 'https://neostrikc.com/pay.php?success=1&oid=' . urlencode($order_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title>NEO STRIKE — Pay Now</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0d1117 0%, #161b22 100%);
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: #1c2128;
            border: 1px solid #30363d;
            border-radius: 20px;
            padding: 32px 24px;
            max-width: 420px;
            width: 100%;
            text-align: center;
        }
        .icon { font-size: 52px; margin-bottom: 10px; }
        h1 { font-size: 20px; color: #58a6ff; margin-bottom: 4px; }
        .sub { color: #8b949e; font-size: 13px; margin-bottom: 24px; }
        .order-box {
            background: #21262d;
            border-radius: 10px;
            padding: 12px 16px;
            margin-bottom: 24px;
            font-size: 13px;
            color: #c9d1d9;
            text-align: left;
            word-break: break-all;
        }
        .order-box b { color: #58a6ff; }
        #cf-pay-btn {
            background: linear-gradient(135deg, #238636, #2ea043);
            color: #fff;
            border: none;
            border-radius: 12px;
            padding: 16px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            width: 100%;
            letter-spacing: 0.5px;
        }
        #cf-pay-btn:disabled { opacity: 0.6; cursor: not-allowed; }
        .status { margin-top: 14px; color: #8b949e; font-size: 13px; min-height: 20px; }
        .secured { margin-top: 20px; color: #484f58; font-size: 11px; }
        .tg-link { display:block; margin-top:14px; color:#58a6ff; font-size:13px; text-decoration:none; }
    </style>
</head>
<body>
<div class="card">
    <div class="icon">🛒</div>
    <h1>NEO STRIKE SHOP</h1>
    <div class="sub">Secure payment · UPI / Card / NetBanking</div>

    <div class="order-box">
        🆔 Order ID: <b><?= htmlspecialchars($order_id) ?></b>
    </div>

    <button id="cf-pay-btn" onclick="startPay()">💳 Pay Now</button>
    <div class="status" id="status"></div>

    <div class="secured">🔒 256-bit SSL · Secured by Cashfree Payments</div>
    <a href="https://t.me/NEO_STRIKE_BOT" class="tg-link">← Back to Telegram</a>
</div>

<script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
<script>
var SESSION_ID  = "<?= addslashes($session_id) ?>";
var RETURN_URL  = "<?= addslashes($return_url) ?>";

var cashfree;
try {
    cashfree = Cashfree({ mode: "production" });
} catch(e) {
    document.getElementById('status').innerHTML = '❌ SDK load error: ' + e.message;
}

function startPay() {
    var btn = document.getElementById('cf-pay-btn');
    var st  = document.getElementById('status');
    btn.disabled = true;
    st.innerHTML = '⏳ Opening payment...';

    if (!cashfree) {
        st.innerHTML = '❌ Payment SDK not loaded. Refresh karo.';
        btn.disabled = false;
        return;
    }

    cashfree.checkout({
        paymentSessionId: SESSION_ID,
        returnUrl: RETURN_URL
    }).then(function(res) {
        if (res.error) {
            st.innerHTML = '❌ ' + res.error.message;
            btn.disabled = false;
        }
        if (res.redirect) {
            st.innerHTML = '🔄 Redirecting to payment...';
        }
        if (res.paymentDetails) {
            st.innerHTML = '✅ Payment done! Telegram check karo.';
            setTimeout(function(){ window.location.href = RETURN_URL; }, 1500);
        }
    }).catch(function(e) {
        st.innerHTML = '❌ Error: ' + e.message;
        btn.disabled = false;
    });
}

// Auto open after 800ms
window.addEventListener('load', function() {
    setTimeout(startPay, 800);
});
</script>
</body>
</html>
