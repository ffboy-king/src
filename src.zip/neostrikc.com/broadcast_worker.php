<?php
/**
 * BROADCAST WORKER — Background mein chalta hai
 * Bot se trigger hota hai, PHP timeout se alag process hai
 * Directly call mat karo — bot1.php se trigger hota hai
 */

error_reporting(0);
ini_set('display_errors', 0);

// ── Time limit hata do — jitna bhi time lage chalega ──────────
set_time_limit(0);
ignore_user_abort(true);

define('BOT_TOKEN', '8672791705:AAEOQ-yV2ULvK_cN5P1-uwz2I4znhzTz4LU');
define('OWNER_ID',  '6680567083');
define('DB_FILE',   __DIR__ . '/shop_data.json');

// ── Input params ──────────────────────────────────────────────
$job_id    = isset($_GET['job_id'])    ? trim($_GET['job_id'])    : '';
$secret    = isset($_GET['secret'])    ? trim($_GET['secret'])    : '';

// Simple secret check — bahar se direct call block karo
$expected_secret = md5(BOT_TOKEN . date('YmdH')); // har ghante badalta hai
if ($secret !== $expected_secret) {
    http_response_code(403);
    exit('Forbidden');
}

if (empty($job_id)) { exit('No job'); }

// ── Load DB ───────────────────────────────────────────────────
function loadDB() {
    if (!file_exists(DB_FILE)) return [];
    $d = json_decode(file_get_contents(DB_FILE), true);
    return $d ?: [];
}

function saveDB($data) {
    file_put_contents(DB_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// ── Telegram API ──────────────────────────────────────────────
function apiCall($method, $data) {
    $url = "https://api.telegram.org/bot" . BOT_TOKEN . "/" . $method;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $data,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT        => 15,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

function apiCallWithRetry($method, $data, $max_retries = 2) {
    for ($attempt = 0; $attempt <= $max_retries; $attempt++) {
        $res = apiCall($method, $data);
        if ($res && isset($res['result'])) return $res;
        if (isset($res['error_code'])) {
            if ($res['error_code'] == 429) {
                $wait = isset($res['parameters']['retry_after']) ? (int)$res['parameters']['retry_after'] : 5;
                sleep(min($wait + 1, 30));
                continue;
            }
            if (in_array($res['error_code'], [403, 400])) return null; // blocked/invalid — skip
        }
        if ($attempt < $max_retries) usleep(300000);
    }
    return null;
}

function tgSend($chat_id, $text) {
    apiCallWithRetry('sendMessage', [
        'chat_id'    => (string)$chat_id,
        'text'       => $text,
        'parse_mode' => 'HTML',
    ]);
}

// ── Load job ──────────────────────────────────────────────────
$db  = loadDB();
$job = isset($db['bc_jobs'][$job_id]) ? $db['bc_jobs'][$job_id] : null;

if (!$job || isset($job['done'])) exit('Job not found or already done');

// Mark as running
$db['bc_jobs'][$job_id]['status'] = 'running';
$db['bc_jobs'][$job_id]['started_at'] = date('Y-m-d H:i:s');
saveDB($db);

$owner_id  = $job['owner_id'];
$text_msg  = isset($job['text_msg'])  ? $job['text_msg']  : null;
$photo_id  = isset($job['photo_id'])  ? $job['photo_id']  : null;
$video_id  = isset($job['video_id'])  ? $job['video_id']  : null;
$voice_id  = isset($job['voice_id'])  ? $job['voice_id']  : null;
$caption   = isset($job['caption'])   ? $job['caption']   : '';
$bc_type   = isset($job['bc_type'])   ? $job['bc_type']   : 'text';

// ── Broadcast loop ────────────────────────────────────────────
$sent    = 0;
$failed  = 0;
$msg_ids = [];

$db_fresh = loadDB();
$users    = isset($db_fresh['users']) ? $db_fresh['users'] : [];

foreach ($users as $uid => $u) {
    if ((string)$uid === (string)OWNER_ID) continue;

    $res      = null;
    $main_mid = null;
    $ok       = false;

    if ($photo_id) {
        $cap  = !empty($caption) ? $caption : (!empty($text_msg) ? $text_msg : '');
        $data = ['chat_id' => (string)$uid, 'photo' => $photo_id, 'parse_mode' => 'HTML'];
        if (!empty($cap)) $data['caption'] = $cap;
        $res = apiCallWithRetry('sendPhoto', $data);
        if ($res && isset($res['result']['message_id'])) {
            $main_mid = $res['result']['message_id'];
            $ok = true;
        }

    } elseif ($video_id) {
        $cap  = !empty($caption) ? $caption : (!empty($text_msg) ? $text_msg : '');
        $data = ['chat_id' => (string)$uid, 'video' => $video_id, 'parse_mode' => 'HTML'];
        if (!empty($cap)) $data['caption'] = $cap;
        $res = apiCallWithRetry('sendVideo', $data);
        if ($res && isset($res['result']['message_id'])) {
            $main_mid = $res['result']['message_id'];
            $ok = true;
        }

    } elseif ($voice_id) {
        $res = apiCallWithRetry('sendVoice', ['chat_id' => (string)$uid, 'voice' => $voice_id]);
        if ($res && isset($res['result']['message_id'])) {
            $main_mid = $res['result']['message_id'];
            $ok = true;
            $cap = !empty($caption) ? $caption : (!empty($text_msg) ? $text_msg : '');
            if (!empty($cap)) {
                usleep(80000);
                apiCallWithRetry('sendMessage', ['chat_id' => (string)$uid, 'text' => $cap, 'parse_mode' => 'HTML']);
            }
        }

    } elseif ($text_msg) {
        $res = apiCallWithRetry('sendMessage', [
            'chat_id'    => (string)$uid,
            'text'       => $text_msg,
            'parse_mode' => 'HTML',
        ]);
        if ($res && isset($res['result']['message_id'])) {
            $main_mid = $res['result']['message_id'];
            $ok = true;
        }
    }

    if ($ok && $main_mid) {
        $msg_ids[(string)$uid] = (int)$main_mid;
        $sent++;
    } else {
        $failed++;
    }

    usleep(80000); // 80ms — safe for Telegram rate limits
}

// ── Save broadcast result ─────────────────────────────────────
$db2   = loadDB();
$bc_id = 'bc_' . time();
$db2['broadcasts'][$bc_id] = [
    'id'      => $bc_id,
    'type'    => $bc_type,
    'content' => $text_msg,
    'caption' => $caption,
    'msg_ids' => $msg_ids,
    'date'    => date('Y-m-d H:i:s'),
];
$db2['bc_jobs'][$job_id]['done']       = true;
$db2['bc_jobs'][$job_id]['status']     = 'done';
$db2['bc_jobs'][$job_id]['finished_at'] = date('Y-m-d H:i:s');
saveDB($db2);

// ── Notify owner ──────────────────────────────────────────────
$type_upper = strtoupper($bc_type);
$cap_line   = !empty($caption)
    ? "\n📝 Caption : <i>" . htmlspecialchars(substr($caption, 0, 60)) . "</i>"
    : "";
tgSend($owner_id,
    "✅ <b>Broadcast Complete!</b>\n\n"
    . "📤 Type   : <b>{$type_upper}</b>{$cap_line}\n"
    . "✔️ Sent   : <b>{$sent}</b>\n"
    . "❌ Failed : <b>{$failed}</b>\n"
    . "🆔 BC ID  : <code>{$bc_id}</code>\n\n"
    . "🗑 Delete karna ho to: 📢 Broadcast → 🗑 Delete"
);

exit('done');
