<?php
$fileName = "status.json";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        "expiry" => isset($_POST['expiry_status']) ? ($_POST['expiry_status'] == 'true') : false,
        "redirect" => $_POST['telegram_link'] ?? "https://t.me/"
    ];
    file_put_contents($fileName, json_encode($data, JSON_PRETTY_PRINT));
}

// Current Data Read
$currentData = file_exists($fileName) ? json_decode(file_get_contents($fileName), true) : ["expiry" => false, "redirect" => "https://t.me/"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REAPER ADMIN</title>
    <style>
        body { background: #0d1117; color: #c9d1d9; font-family: sans-serif; display: flex; justify-content: center; padding-top: 50px; }
        .box { background: #161b22; padding: 25px; border-radius: 12px; border: 1px solid #30363d; width: 350px; text-align: center; }
        h2 { color: #00FF99; margin-bottom: 20px; }
        input[type="text"] { width: 100%; padding: 10px; margin: 10px 0; background: #0d1117; border: 1px solid #30363d; color: white; border-radius: 5px; box-sizing: border-box; }
        select { width: 100%; padding: 10px; margin: 10px 0; background: #0d1117; border: 1px solid #30363d; color: white; border-radius: 5px; }
        button { width: 100%; padding: 12px; background: #00FF99; border: none; color: #0d1117; font-weight: bold; border-radius: 5px; cursor: pointer; margin-top: 10px; }
        .info { font-size: 11px; color: #8b949e; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="box">
        <h2>⚡ ONLINE CONTROL</h2>
        <form method="POST">
            <label>Mod Status:</label>
            <select name="expiry_status">
                <option value="false" <?php if(!$currentData['expiry']) echo 'selected'; ?>>✅ ONLINE (Working)</option>
                <option value="true" <?php if($currentData['expiry']) echo 'selected'; ?>>🚫 EXPIRED (Block)</option>
            </select>

            <label>Telegram Link:</label>
            <input type="text" name="telegram_link" value="<?php echo $currentData['redirect']; ?>" placeholder="https://t.me/your_link">

            <button type="submit">UPDATE SERVER DATA</button>
        </form>
        <div class="info">Target: <?php echo $_SERVER['HTTP_HOST']; ?>/status.json</div>
    </div>
</body>
</html>