<?php

include('conn.php');
include('mail.php');

// For Credits
$sql = "SELECT * FROM credit where id=1";
$result = mysqli_query($conn, $sql);
$credit = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= BASE_NAME ?> - Register</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --cyan:    #00f5ff;
            --magenta: #ff00c8;
            --gold:    #ffd700;
            --dark:    #020010;
            --card-bg: rgba(0, 5, 30, 0.75);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            min-height: 100vh;
            background: var(--dark);
            font-family: 'Rajdhani', sans-serif;
            overflow-y: auto;
            overflow-x: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 0;
        }

        /* ── CANVAS BACKGROUND ── */
        #bgCanvas {
            position: fixed;
            inset: 0;
            z-index: 0;
        }

        /* ── ROTATING GLOW RINGS ── */
        .glow-ring {
            position: fixed;
            border-radius: 50%;
            pointer-events: none;
            z-index: 1;
        }

        .ring-1 {
            width: 700px; height: 700px;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            border: 2px solid rgba(0, 245, 255, 0.15);
            box-shadow:
                0 0 40px rgba(0, 245, 255, 0.3),
                inset 0 0 40px rgba(0, 245, 255, 0.05);
            animation: rotateRing 12s linear infinite;
        }

        .ring-2 {
            width: 520px; height: 520px;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            border: 1.5px solid rgba(255, 0, 200, 0.2);
            box-shadow:
                0 0 30px rgba(255, 0, 200, 0.25),
                inset 0 0 30px rgba(255, 0, 200, 0.05);
            animation: rotateRing 8s linear infinite reverse;
        }

        .ring-3 {
            width: 860px; height: 860px;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            border: 1px solid rgba(255, 215, 0, 0.1);
            box-shadow: 0 0 60px rgba(255, 215, 0, 0.1);
            animation: rotateRing 20s linear infinite;
        }

        /* Rotating dots on rings */
        .ring-dot {
            position: fixed;
            width: 10px; height: 10px;
            border-radius: 50%;
            z-index: 2;
            pointer-events: none;
        }

        @keyframes rotateRing {
            from { transform: translate(-50%, -50%) rotate(0deg); }
            to   { transform: translate(-50%, -50%) rotate(360deg); }
        }

        @keyframes orbitDot {
            from { transform: translate(-50%, -50%) rotate(0deg) translateX(350px) rotate(0deg); }
            to   { transform: translate(-50%, -50%) rotate(360deg) translateX(350px) rotate(-360deg); }
        }

        @keyframes orbitDot2 {
            from { transform: translate(-50%, -50%) rotate(120deg) translateX(260px) rotate(-120deg); }
            to   { transform: translate(-50%, -50%) rotate(480deg) translateX(260px) rotate(-480deg); }
        }

        .dot-1 {
            width: 12px; height: 12px;
            top: 50%; left: 50%;
            background: var(--cyan);
            box-shadow: 0 0 20px var(--cyan), 0 0 40px var(--cyan);
            animation: orbitDot 12s linear infinite;
        }

        .dot-2 {
            width: 8px; height: 8px;
            top: 50%; left: 50%;
            background: var(--magenta);
            box-shadow: 0 0 15px var(--magenta), 0 0 30px var(--magenta);
            animation: orbitDot2 8s linear infinite reverse;
        }

        .dot-3 {
            width: 6px; height: 6px;
            top: 50%; left: 50%;
            background: var(--gold);
            box-shadow: 0 0 10px var(--gold), 0 0 20px var(--gold);
            animation: orbitDot 20s linear infinite reverse;
        }

        /* ── MAIN WRAPPER ── */
        .main-wrap {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 440px;
            padding: 0 1.5rem;
        }

        /* ── CARD ── */
        .login-card {
            background: var(--card-bg);
            border: 1px solid rgba(0, 245, 255, 0.2);
            border-radius: 20px;
            padding: 1.5rem 1.5rem;
            backdrop-filter: blur(20px);
            box-shadow:
                0 0 0 1px rgba(0,245,255,0.05),
                0 0 40px rgba(0, 245, 255, 0.08),
                0 0 80px rgba(255, 0, 200, 0.05),
                0 30px 60px rgba(0,0,0,0.6);
            animation: cardIn 0.7s cubic-bezier(0.22, 1, 0.36, 1) forwards;
            opacity: 0;
        }

        @keyframes cardIn {
            from { opacity: 0; transform: translateY(30px) scale(0.97); }
            to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Corner accents */
        .login-card::before,
        .login-card::after {
            content: '';
            position: absolute;
            width: 40px; height: 40px;
            border-color: var(--cyan);
            border-style: solid;
        }

        .login-card::before {
            top: -1px; left: -1px;
            border-width: 2px 0 0 2px;
            border-radius: 20px 0 0 0;
        }

        .login-card::after {
            bottom: -1px; right: -1px;
            border-width: 0 2px 2px 0;
            border-radius: 0 0 20px 0;
        }

        /* ── LOGO ── */
        .logo-wrap {
            text-align: center;
            margin-bottom: 1rem;
            animation: fadeDown 0.6s 0.3s ease both;
        }

        @keyframes fadeDown {
            from { opacity: 0; transform: translateY(-20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .logo-title {
            font-family: 'Orbitron', monospace;
            font-size: 1.6rem;
            font-weight: 900;
            letter-spacing: 3px;
            background: linear-gradient(90deg, var(--cyan), var(--magenta), var(--gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .logo-sub {
            color: rgba(255,255,255,0.45);
            font-size: 0.8rem;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-top: 0.3rem;
        }

        /* ── STATUS ── */
        .msg-status {
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 999;
            width: 90%;
            max-width: 440px;
        }
        .msg-status:empty { display: none; }

        /* ── FORM ── */
        .field-group { margin-bottom: 1rem; }

        .field-label {
            display: block;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--cyan);
            margin-bottom: 0.5rem;
        }

        .field-wrap {
            position: relative;
        }

        .field-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(0, 245, 255, 0.5);
            pointer-events: none;
            transition: color 0.3s;
        }

        .field-icon-right {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(0, 245, 255, 0.5);
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
            transition: color 0.3s;
        }

        .field-icon-right:hover { color: var(--cyan); }

        .field-input {
            width: 100%;
            padding: 0.85rem 1rem 0.85rem 3rem;
            background: rgba(0, 245, 255, 0.04);
            border: 1px solid rgba(0, 245, 255, 0.2);
            border-radius: 10px;
            color: #fff;
            font-family: 'Rajdhani', sans-serif;
            font-size: 1rem;
            font-weight: 500;
            letter-spacing: 0.5px;
            outline: none;
            transition: all 0.3s ease;
        }

        .field-input.has-toggle {
            padding-right: 3rem;
        }

        .field-input::placeholder { color: rgba(255,255,255,0.25); }

        .field-input:focus {
            border-color: var(--cyan);
            background: rgba(0, 245, 255, 0.08);
            box-shadow: 0 0 0 3px rgba(0, 245, 255, 0.1), 0 0 20px rgba(0, 245, 255, 0.15);
            transform: translateY(-1px);
        }

        .field-input:read-only {
            background: rgba(0, 245, 255, 0.02);
            border-color: rgba(0, 245, 255, 0.1);
            color: rgba(255,255,255,0.35);
            cursor: not-allowed;
        }

        .field-wrap:focus-within .field-icon { color: var(--cyan); }

        .field-error {
            color: #ff6b9d;
            font-size: 0.78rem;
            margin-top: 0.4rem;
            letter-spacing: 0.5px;
        }

        /* ── BUTTON ── */
        .btn-submit {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, rgba(0,245,255,0.15), rgba(255,0,200,0.15));
            border: 1px solid rgba(0, 245, 255, 0.5);
            border-radius: 10px;
            color: #fff;
            font-family: 'Orbitron', monospace;
            font-size: 0.9rem;
            font-weight: 700;
            letter-spacing: 3px;
            text-transform: uppercase;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.6rem;
            margin-top: 0.5rem;
        }

        .btn-submit::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, var(--cyan), var(--magenta));
            opacity: 0;
            transition: opacity 0.3s;
        }

        .btn-submit:hover::before { opacity: 0.2; }

        .btn-submit:hover {
            border-color: var(--cyan);
            box-shadow:
                0 0 20px rgba(0, 245, 255, 0.4),
                0 0 40px rgba(0, 245, 255, 0.2),
                0 10px 30px rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }

        .btn-submit:active { transform: translateY(0); }

        .btn-submit svg, .btn-submit span { position: relative; z-index: 1; }

        /* Ripple */
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(0, 245, 255, 0.4);
            transform: scale(0);
            animation: rippleAnim 0.6s ease-out forwards;
            pointer-events: none;
            z-index: 0;
        }

        @keyframes rippleAnim {
            to { transform: scale(4); opacity: 0; }
        }

        /* ── DIVIDER ── */
        .divider {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin: 1.5rem 0 1rem;
        }

        .divider-line {
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(0,245,255,0.2), transparent);
        }

        .divider-text {
            font-size: 0.7rem;
            color: rgba(255,255,255,0.3);
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        /* ── LOGIN LINK ── */
        .register-row {
            text-align: center;
        }

        .register-row p {
            font-size: 0.85rem;
            color: rgba(255,255,255,0.4);
            letter-spacing: 0.5px;
        }

        .register-row a {
            color: var(--cyan);
            font-weight: 700;
            text-decoration: none;
            letter-spacing: 1px;
            transition: text-shadow 0.2s, color 0.2s;
        }

        .register-row a:hover {
            color: #fff;
            text-shadow: 0 0 10px var(--cyan);
        }

        /* ── FOOTER ── */
        .footer-note {
            text-align: center;
            margin-top: 1.5rem;
        }

        .footer-note p {
            font-size: 0.75rem;
            color: rgba(255, 215, 0, 0.6);
            letter-spacing: 1.5px;
        }

        .footer-note a {
            color: var(--gold);
            font-weight: 700;
            text-decoration: none;
            transition: text-shadow 0.2s;
        }

        .footer-note a:hover { text-shadow: 0 0 10px var(--gold); }

        /* ── SCAN LINE EFFECT ── */
        .scanlines {
            position: fixed;
            inset: 0;
            z-index: 3;
            pointer-events: none;
            background: repeating-linear-gradient(
                to bottom,
                transparent 0px,
                transparent 3px,
                rgba(0, 245, 255, 0.015) 3px,
                rgba(0, 245, 255, 0.015) 4px
            );
        }

        @media (max-width: 480px) {
            .login-card { padding: 2rem 1.4rem; }
            .logo-title { font-size: 1.3rem; }
            .ring-1 { width: 400px; height: 400px; }
            .ring-2 { width: 300px; height: 300px; }
            .ring-3 { width: 500px; height: 500px; }
        }
    </style>
</head>
<body>

    <!-- Animated particle canvas -->
    <canvas id="bgCanvas"></canvas>

    <!-- Glow Rings -->
    <div class="glow-ring ring-1"></div>
    <div class="glow-ring ring-2"></div>
    <div class="glow-ring ring-3"></div>

    <!-- Orbiting dots -->
    <div class="ring-dot dot-1"></div>
    <div class="ring-dot dot-2"></div>
    <div class="ring-dot dot-3"></div>

    <!-- Scan lines overlay -->
    <div class="scanlines"></div>

    <!-- Message Status (floating, does not push card) -->
    <div class="msg-status">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <!-- Main Content -->
    <div class="main-wrap">

        <!-- Register Card -->
        <div class="login-card" style="position:relative;">

            <!-- Logo / Header -->
            <div class="logo-wrap">
                <div class="logo-title">CREATE ACCOUNT</div>
                <div class="logo-sub">Join the Network</div>
            </div>

            <!-- Form -->
            <?= form_open('', ['autocomplete' => 'off']) ?>

                <!-- Email -->
                <div class="field-group">
                    <label class="field-label" for="email">Email</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207"/>
                            </svg>
                        </span>
                        <input
                            type="email"
                            name="email"
                            id="email"
                            required
                            minlength="13"
                            maxlength="40"
                            value="<?= old('email') ?>"
                            class="field-input"
                            placeholder="Enter your email"
                            autocomplete="off"
                        >
                    </div>
                    <?php if ($validation->hasError('email')) : ?>
                        <p class="field-error"><?= $validation->getError('email') ?></p>
                    <?php endif; ?>
                </div>

                <!-- Username -->
                <div class="field-group">
                    <label class="field-label" for="username">Username</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                            </svg>
                        </span>
                        <input
                            type="text"
                            name="username"
                            id="username"
                            required
                            minlength="4"
                            maxlength="24"
                            value="<?= old('username') ?>"
                            class="field-input"
                            placeholder="Choose a username"
                            autocomplete="off"
                        >
                    </div>
                    <?php if ($validation->hasError('username')) : ?>
                        <p class="field-error"><?= $validation->getError('username') ?></p>
                    <?php endif; ?>
                </div>

                <!-- Full Name -->
                <div class="field-group">
                    <label class="field-label" for="fullname">Full Name</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </span>
                        <input
                            type="text"
                            name="fullname"
                            id="fullname"
                            required
                            minlength="4"
                            maxlength="24"
                            value="<?= old('fullname') ?>"
                            class="field-input"
                            placeholder="Enter your full name"
                            autocomplete="off"
                        >
                    </div>
                    <?php if ($validation->hasError('fullname')) : ?>
                        <p class="field-error"><?= $validation->getError('fullname') ?></p>
                    <?php endif; ?>
                </div>

                <!-- Password -->
                <div class="field-group">
                    <label class="field-label" for="password">Password</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                            </svg>
                        </span>
                        <input
                            type="password"
                            name="password"
                            id="password"
                            required
                            minlength="6"
                            maxlength="24"
                            class="field-input has-toggle"
                            placeholder="Create a password"
                            autocomplete="new-password"
                        >
                        <button type="button" class="field-icon-right" onclick="togglePassword('password','toggleIcon1')">
                            <svg id="toggleIcon1" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>
                    </div>
                    <?php if ($validation->hasError('password')) : ?>
                        <p class="field-error"><?= $validation->getError('password') ?></p>
                    <?php endif; ?>
                </div>

                <!-- Confirm Password -->
                <div class="field-group">
                    <label class="field-label" for="password2">Confirm Password</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                            </svg>
                        </span>
                        <input
                            type="password"
                            name="password2"
                            id="password2"
                            required
                            minlength="6"
                            maxlength="24"
                            class="field-input has-toggle"
                            placeholder="Confirm your password"
                            autocomplete="new-password"
                        >
                        <button type="button" class="field-icon-right" onclick="togglePassword('password2','toggleIcon2')">
                            <svg id="toggleIcon2" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>
                    </div>
                    <?php if ($validation->hasError('password2')) : ?>
                        <p class="field-error"><?= $validation->getError('password2') ?></p>
                    <?php endif; ?>
                </div>

                <!-- Referral Code -->
                <div class="field-group">
                    <label class="field-label" for="referral">Referral Code</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"/>
                            </svg>
                        </span>
                        <input
                            type="text"
                            name="referral"
                            id="referral"
                            required
                            maxlength="25"
                            value="<?= old('referral') ?>"
                            class="field-input"
                            placeholder="Enter referral code"
                            autocomplete="off"
                        >
                    </div>
                    <?php if ($validation->hasError('referral')) : ?>
                        <p class="field-error"><?= $validation->getError('referral') ?></p>
                    <?php endif; ?>
                </div>

                <!-- IP Address (readonly) -->
                <div class="field-group">
                    <label class="field-label" for="ip">IP Address</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/>
                            </svg>
                        </span>
                        <input
                            type="text"
                            id="ip"
                            readonly
                            class="field-input"
                            placeholder="<?php echo $user_ip ?>"
                        >
                    </div>
                </div>

                <!-- Submit -->
                <button type="submit" class="btn-submit" id="submitBtn">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                    </svg>
                    <span>CREATE ACCOUNT</span>
                </button>

            <?= form_close() ?>

            <!-- Divider -->
            <div class="divider">
                <div class="divider-line"></div>
                <div class="divider-text">or</div>
                <div class="divider-line"></div>
            </div>

            <!-- Login Link -->
            <div class="register-row">
                <p>Already have an account?
                    <a href="<?= site_url('login') ?>">SIGN IN</a>
                </p>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer-note">
            <p>TO BUY PANEL DM :-
                <a href="https://t.me/Rohan_Moder/s" target="_blank">@Rohan_Moder</a>
            </p>
        </div>
    </div>

    <script>
    /* ── PARTICLE CANVAS ── */
    const canvas = document.getElementById('bgCanvas');
    const ctx = canvas.getContext('2d');
    let W, H, particles = [];

    function resize() {
        W = canvas.width  = window.innerWidth;
        H = canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    const COLORS = ['#00f5ff', '#ff00c8', '#ffd700', '#7b61ff'];

    function rand(a, b) { return Math.random() * (b - a) + a; }

    class Particle {
        constructor() { this.reset(true); }
        reset(init) {
            this.x  = rand(0, W);
            this.y  = init ? rand(0, H) : H + 10;
            this.vy = rand(-0.4, -1.2);
            this.vx = rand(-0.2, 0.2);
            this.r  = rand(1, 2.5);
            this.color = COLORS[Math.floor(Math.random() * COLORS.length)];
            this.alpha = rand(0.3, 0.9);
            this.life  = 0;
            this.maxLife = rand(150, 350);
        }
        update() {
            this.x += this.vx; this.y += this.vy; this.life++;
            if (this.life > this.maxLife || this.y < -10) this.reset(false);
        }
        draw() {
            ctx.save();
            ctx.globalAlpha = this.alpha * (1 - this.life / this.maxLife);
            ctx.fillStyle = this.color;
            ctx.shadowBlur = 8;
            ctx.shadowColor = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }
    }

    for (let i = 0; i < 120; i++) particles.push(new Particle());

    function drawCenterGlow(t) {
        const cx = W / 2, cy = H / 2;
        const pulse = 0.7 + 0.3 * Math.sin(t * 0.001);

        const g1 = ctx.createRadialGradient(cx, cy, 0, cx, cy, 380 * pulse);
        g1.addColorStop(0,   'rgba(0, 245, 255, 0.06)');
        g1.addColorStop(0.5, 'rgba(255, 0, 200, 0.03)');
        g1.addColorStop(1,   'transparent');
        ctx.fillStyle = g1;
        ctx.fillRect(0, 0, W, H);

        const g2 = ctx.createRadialGradient(cx, cy, 0, cx, cy, 200 * pulse);
        g2.addColorStop(0,   'rgba(0, 245, 255, 0.04)');
        g2.addColorStop(1,   'transparent');
        ctx.fillStyle = g2;
        ctx.fillRect(0, 0, W, H);
    }

    function animate(t) {
        ctx.clearRect(0, 0, W, H);
        const bg = ctx.createLinearGradient(0, 0, W, H);
        bg.addColorStop(0,   '#020010');
        bg.addColorStop(0.5, '#04001a');
        bg.addColorStop(1,   '#020010');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, W, H);
        drawCenterGlow(t);
        particles.forEach(p => { p.update(); p.draw(); });
        requestAnimationFrame(animate);
    }
    requestAnimationFrame(animate);

    /* ── RIPPLE ON BUTTON ── */
    document.getElementById('submitBtn').addEventListener('click', function(e) {
        const rect = this.getBoundingClientRect();
        const ripple = document.createElement('span');
        const size = Math.max(rect.width, rect.height);
        ripple.style.cssText = `
            width:${size}px; height:${size}px;
            left:${e.clientX - rect.left - size/2}px;
            top:${e.clientY - rect.top - size/2}px;
        `;
        ripple.classList.add('ripple');
        this.appendChild(ripple);
        setTimeout(() => ripple.remove(), 700);
    });

    /* ── TOGGLE PASSWORD ── */
    function togglePassword(inputId, iconId) {
        const input = document.getElementById(inputId);
        const icon  = document.getElementById(iconId);
        if (input.type === 'password') {
            input.type = 'text';
            icon.innerHTML = `
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
            `;
        } else {
            input.type = 'password';
            icon.innerHTML = `
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
            `;
        }
    }
    </script>
</body>
</html>
