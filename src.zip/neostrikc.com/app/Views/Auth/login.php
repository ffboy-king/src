<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= BASE_NAME ?> - Login</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --cyan:    #00f5ff;
            --magenta: #ff00c8;
            --gold:    #ffd700;
            --dark:    #020010;
            --card-bg: rgba(0, 5, 30, 0.75);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            min-height: 100vh;
            background: var(--dark);
            font-family: 'Rajdhani', sans-serif;
            overflow-y: auto;
            overflow-x: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
        }

        /* ── CANVAS BACKGROUND ── */
        #bgCanvas {
            position: fixed;
            inset: 0;
            z-index: 0;
        }

        /* ── ROTATING GLOW RINGS ── */
        .glow-ring {
            position: fixed;
            border-radius: 50%;
            pointer-events: none;
            z-index: 1;
        }

        .ring-1 {
            width: 700px; height: 700px;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            border: 2px solid rgba(0, 245, 255, 0.15);
            box-shadow:
                0 0 40px rgba(0, 245, 255, 0.3),
                inset 0 0 40px rgba(0, 245, 255, 0.05);
            animation: rotateRing 12s linear infinite;
        }

        .ring-2 {
            width: 520px; height: 520px;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            border: 1.5px solid rgba(255, 0, 200, 0.2);
            box-shadow:
                0 0 30px rgba(255, 0, 200, 0.25),
                inset 0 0 30px rgba(255, 0, 200, 0.05);
            animation: rotateRing 8s linear infinite reverse;
        }

        .ring-3 {
            width: 860px; height: 860px;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            border: 1px solid rgba(255, 215, 0, 0.1);
            box-shadow: 0 0 60px rgba(255, 215, 0, 0.1);
            animation: rotateRing 20s linear infinite;
        }

        /* Rotating dots on rings */
        .ring-dot {
            position: fixed;
            width: 10px; height: 10px;
            border-radius: 50%;
            z-index: 2;
            pointer-events: none;
        }

        @keyframes rotateRing {
            from { transform: translate(-50%, -50%) rotate(0deg); }
            to   { transform: translate(-50%, -50%) rotate(360deg); }
        }

        @keyframes orbitDot {
            from { transform: translate(-50%, -50%) rotate(0deg) translateX(350px) rotate(0deg); }
            to   { transform: translate(-50%, -50%) rotate(360deg) translateX(350px) rotate(-360deg); }
        }

        @keyframes orbitDot2 {
            from { transform: translate(-50%, -50%) rotate(120deg) translateX(260px) rotate(-120deg); }
            to   { transform: translate(-50%, -50%) rotate(480deg) translateX(260px) rotate(-480deg); }
        }

        .dot-1 {
            width: 12px; height: 12px;
            top: 50%; left: 50%;
            background: var(--cyan);
            box-shadow: 0 0 20px var(--cyan), 0 0 40px var(--cyan);
            animation: orbitDot 12s linear infinite;
        }

        .dot-2 {
            width: 8px; height: 8px;
            top: 50%; left: 50%;
            background: var(--magenta);
            box-shadow: 0 0 15px var(--magenta), 0 0 30px var(--magenta);
            animation: orbitDot2 8s linear infinite reverse;
        }

        .dot-3 {
            width: 6px; height: 6px;
            top: 50%; left: 50%;
            background: var(--gold);
            box-shadow: 0 0 10px var(--gold), 0 0 20px var(--gold);
            animation: orbitDot 20s linear infinite reverse;
            transform: translate(-50%, -50%) rotate(0deg) translateX(430px) rotate(0deg);
        }

        @keyframes orbitDot3rev {
            from { transform: translate(-50%, -50%) rotate(60deg) translateX(430px) rotate(-60deg); }
            to   { transform: translate(-50%, -50%) rotate(-300deg) translateX(430px) rotate(300deg); }
        }

        /* ── MAIN WRAPPER ── */
        .main-wrap {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 440px;
            padding: 0 1.5rem;
        }

        /* ── CARD ── */
        .login-card {
            background: var(--card-bg);
            border: 1px solid rgba(0, 245, 255, 0.2);
            border-radius: 20px;
            padding: 1.5rem 1.5rem;
            backdrop-filter: blur(20px);
            box-shadow:
                0 0 0 1px rgba(0,245,255,0.05),
                0 0 40px rgba(0, 245, 255, 0.08),
                0 0 80px rgba(255, 0, 200, 0.05),
                0 30px 60px rgba(0,0,0,0.6);
            animation: cardIn 0.7s cubic-bezier(0.22, 1, 0.36, 1) forwards;
            opacity: 0;
        }

        @keyframes cardIn {
            from { opacity: 0; transform: translateY(30px) scale(0.97); }
            to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Corner accents */
        .login-card::before,
        .login-card::after {
            content: '';
            position: absolute;
            width: 40px; height: 40px;
            border-color: var(--cyan);
            border-style: solid;
        }

        .login-card::before {
            top: -1px; left: -1px;
            border-width: 2px 0 0 2px;
            border-radius: 20px 0 0 0;
        }

        .login-card::after {
            bottom: -1px; right: -1px;
            border-width: 0 2px 2px 0;
            border-radius: 0 0 20px 0;
        }

        /* ── LOGO ── */
        .logo-wrap {
            text-align: center;
            margin-bottom: 1rem;
            animation: fadeDown 0.6s 0.3s ease both;
        }

        @keyframes fadeDown {
            from { opacity: 0; transform: translateY(-20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulseLogo {
            0%, 100% { box-shadow: 0 0 20px rgba(0,245,255,0.4), 0 0 40px rgba(0,245,255,0.2), inset 0 0 20px rgba(0,245,255,0.05); }
            50%       { box-shadow: 0 0 30px rgba(0,245,255,0.6), 0 0 60px rgba(0,245,255,0.3), inset 0 0 30px rgba(0,245,255,0.1); }
        }

        .logo-icon svg { width: 34px; height: 34px; color: var(--cyan); }

        .logo-title {
            font-family: 'Orbitron', monospace;
            font-size: 1.6rem;
            font-weight: 900;
            letter-spacing: 3px;
            background: linear-gradient(90deg, var(--cyan), var(--magenta), var(--gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .logo-sub {
            color: rgba(255,255,255,0.45);
            font-size: 0.8rem;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-top: 0.3rem;
        }

        /* ── STATUS ── */
        .msg-status {
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 999;
            width: 90%;
            max-width: 440px;
        }
        .msg-status:empty { display: none; }

        /* ── FORM ── */
        .field-group { margin-bottom: 1rem; }

        .field-label {
            display: block;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--cyan);
            margin-bottom: 0.5rem;
        }

        .field-wrap {
            position: relative;
        }

        .field-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(0, 245, 255, 0.5);
            pointer-events: none;
            transition: color 0.3s;
        }

        .field-input {
            width: 100%;
            padding: 0.85rem 1rem 0.85rem 3rem;
            background: rgba(0, 245, 255, 0.04);
            border: 1px solid rgba(0, 245, 255, 0.2);
            border-radius: 10px;
            color: #fff;
            font-family: 'Rajdhani', sans-serif;
            font-size: 1rem;
            font-weight: 500;
            letter-spacing: 0.5px;
            outline: none;
            transition: all 0.3s ease;
        }

        .field-input::placeholder { color: rgba(255,255,255,0.25); }

        .field-input:focus {
            border-color: var(--cyan);
            background: rgba(0, 245, 255, 0.08);
            box-shadow: 0 0 0 3px rgba(0, 245, 255, 0.1), 0 0 20px rgba(0, 245, 255, 0.15);
            transform: translateY(-1px);
        }

        .field-input:focus + .field-icon-right,
        .field-wrap:focus-within .field-icon { color: var(--cyan); }

        .field-error {
            color: #ff6b9d;
            font-size: 0.78rem;
            margin-top: 0.4rem;
            letter-spacing: 0.5px;
        }

        /* ── REMEMBER / FORGOT ── */
        .row-mid {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.6rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .remember-wrap {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
        }

        .remember-wrap input[type="checkbox"] {
            appearance: none;
            width: 16px; height: 16px;
            border: 1px solid rgba(0,245,255,0.4);
            border-radius: 4px;
            background: transparent;
            cursor: pointer;
            position: relative;
            transition: all 0.2s;
        }

        .remember-wrap input[type="checkbox"]:checked {
            background: var(--cyan);
            border-color: var(--cyan);
        }

        .remember-wrap input[type="checkbox"]:checked::after {
            content: '✓';
            position: absolute;
            top: -1px; left: 2px;
            font-size: 11px;
            color: #000;
            font-weight: 900;
        }

        .remember-label {
            font-size: 0.85rem;
            color: rgba(255,255,255,0.5);
            letter-spacing: 0.5px;
        }

        .forgot-link {
            font-size: 0.8rem;
            color: var(--magenta);
            text-decoration: none;
            letter-spacing: 1px;
            transition: color 0.2s, text-shadow 0.2s;
        }

        .forgot-link:hover {
            color: #fff;
            text-shadow: 0 0 10px var(--magenta);
        }

        /* ── BUTTON ── */
        .btn-submit {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, rgba(0,245,255,0.15), rgba(255,0,200,0.15));
            border: 1px solid rgba(0, 245, 255, 0.5);
            border-radius: 10px;
            color: #fff;
            font-family: 'Orbitron', monospace;
            font-size: 0.9rem;
            font-weight: 700;
            letter-spacing: 3px;
            text-transform: uppercase;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.6rem;
        }

        .btn-submit::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, var(--cyan), var(--magenta));
            opacity: 0;
            transition: opacity 0.3s;
        }

        .btn-submit:hover::before { opacity: 0.2; }

        .btn-submit:hover {
            border-color: var(--cyan);
            box-shadow:
                0 0 20px rgba(0, 245, 255, 0.4),
                0 0 40px rgba(0, 245, 255, 0.2),
                0 10px 30px rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }

        .btn-submit:active { transform: translateY(0); }

        .btn-submit svg, .btn-submit span { position: relative; z-index: 1; }

        /* Ripple */
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(0, 245, 255, 0.4);
            transform: scale(0);
            animation: rippleAnim 0.6s ease-out forwards;
            pointer-events: none;
            z-index: 0;
        }

        @keyframes rippleAnim {
            to { transform: scale(4); opacity: 0; }
        }

        /* ── DIVIDER ── */
        .divider {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin: 1.5rem 0 1rem;
        }

        .divider-line {
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(0,245,255,0.2), transparent);
        }

        .divider-text {
            font-size: 0.7rem;
            color: rgba(255,255,255,0.3);
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        /* ── REGISTER LINK ── */
        .register-row {
            text-align: center;
        }

        .register-row p {
            font-size: 0.85rem;
            color: rgba(255,255,255,0.4);
            letter-spacing: 0.5px;
        }

        .register-row a {
            color: var(--cyan);
            font-weight: 700;
            text-decoration: none;
            letter-spacing: 1px;
            transition: text-shadow 0.2s, color 0.2s;
        }

        .register-row a:hover {
            color: #fff;
            text-shadow: 0 0 10px var(--cyan);
        }

        /* ── FOOTER ── */
        .footer-note {
            text-align: center;
            margin-top: 1.5rem;
        }

        .footer-note p {
            font-size: 0.75rem;
            color: rgba(255, 215, 0, 0.6);
            letter-spacing: 1.5px;
        }

        .footer-note a {
            color: var(--gold);
            font-weight: 700;
            text-decoration: none;
            transition: text-shadow 0.2s;
        }

        .footer-note a:hover { text-shadow: 0 0 10px var(--gold); }

        /* ── SCAN LINE EFFECT ── */
        .scanlines {
            position: fixed;
            inset: 0;
            z-index: 3;
            pointer-events: none;
            background: repeating-linear-gradient(
                to bottom,
                transparent 0px,
                transparent 3px,
                rgba(0, 245, 255, 0.015) 3px,
                rgba(0, 245, 255, 0.015) 4px
            );
        }

        @media (max-width: 480px) {
            .login-card { padding: 2rem 1.4rem; }
            .logo-title { font-size: 1.3rem; }
            .ring-1 { width: 400px; height: 400px; }
            .ring-2 { width: 300px; height: 300px; }
            .ring-3 { width: 500px; height: 500px; }
        }
    </style>
</head>
<body>

    <!-- Animated particle canvas -->
    <canvas id="bgCanvas"></canvas>

    <!-- Scan lines overlay -->
    <div class="scanlines"></div>

    <!-- Message Status (floating, does not push card) -->
    <div class="msg-status">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <!-- Main Content -->
    <div class="main-wrap">

        <!-- Login Card -->
        <div class="login-card" style="position:relative;">

            <!-- Logo / Header -->
            <div class="logo-wrap">
                <div class="logo-title">WELCOME BACK</div>
                <div class="logo-sub">Secure Access Portal</div>
            </div>

            <!-- Form -->
            <?= form_open('', ['autocomplete' => 'off']) ?>

                <!-- Username -->
                <div class="field-group">
                    <label class="field-label" for="username">Username</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                            </svg>
                        </span>
                        <input
                            type="text"
                            name="username"
                            id="username"
                            required
                            minlength="4"
                            class="field-input"
                            placeholder="Enter your username"
                            autocomplete="off"
                        >
                    </div>
                    <?php if ($validation->hasError('username')) : ?>
                        <p class="field-error"><?= $validation->getError('username') ?></p>
                    <?php endif; ?>
                </div>

                <!-- Password -->
                <div class="field-group">
                    <label class="field-label" for="password">Password</label>
                    <div class="field-wrap">
                        <span class="field-icon">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                            </svg>
                        </span>
                        <input
                            type="password"
                            name="password"
                            id="password"
                            required
                            minlength="6"
                            class="field-input"
                            placeholder="Enter your password"
                            autocomplete="new-password"
                        >
                    </div>
                    <?php if ($validation->hasError('password')) : ?>
                        <p class="field-error"><?= $validation->getError('password') ?></p>
                    <?php endif; ?>
                </div>

                <!-- Hidden IP -->
                <input type="hidden" name="ip" value="<?= $_SERVER['HTTP_USER_AGENT']; ?>" id="ip" required>

                <!-- Remember / Forgot -->
                <div class="row-mid">
                    <label class="remember-wrap">
                        <input type="checkbox" name="stay_log" id="stay_log" value="yes">
                        <span class="remember-label">Remember me</span>
                    </label>
                    <a href="#" class="forgot-link">FORGOT PASSWORD?</a>
                </div>

                <!-- Submit -->
                <button type="submit" class="btn-submit" id="submitBtn">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/>
                    </svg>
                    <span>SIGN IN</span>
                </button>

            <?= form_close() ?>

            <!-- Divider -->
            <div class="divider">
                <div class="divider-line"></div>
                <div class="divider-text">or</div>
                <div class="divider-line"></div>
            </div>

            <!-- Register Link -->
            <div class="register-row">
                <p>Don't have an account?
                    <a href="<?= site_url('register') ?>">SIGN UP</a>
                </p>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer-note">
            <p>TO BUY PANEL DM :-
                <a href="https://t.me/Rohan_Moder/s" target="_blank">@Rohan_Moder</a>
            </p>
        </div>
    </div>

    <script>
    /* ── PARTICLE CANVAS ── */
    const canvas = document.getElementById('bgCanvas');
    const ctx = canvas.getContext('2d');
    let W, H, particles = [];

    function resize() {
        W = canvas.width  = window.innerWidth;
        H = canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    const COLORS = ['#00f5ff', '#ff00c8', '#ffd700', '#7b61ff'];

    function rand(a, b) { return Math.random() * (b - a) + a; }

    class Particle {
        constructor() { this.reset(true); }
        reset(init) {
            this.x  = rand(0, W);
            this.y  = init ? rand(0, H) : H + 10;
            this.vy = rand(-0.4, -1.2);
            this.vx = rand(-0.2, 0.2);
            this.r  = rand(1, 2.5);
            this.color = COLORS[Math.floor(Math.random() * COLORS.length)];
            this.alpha = rand(0.3, 0.9);
            this.life  = 0;
            this.maxLife = rand(150, 350);
        }
        update() {
            this.x += this.vx; this.y += this.vy; this.life++;
            if (this.life > this.maxLife || this.y < -10) this.reset(false);
        }
        draw() {
            ctx.save();
            ctx.globalAlpha = this.alpha * (1 - this.life / this.maxLife);
            ctx.fillStyle = this.color;
            ctx.shadowBlur = 8;
            ctx.shadowColor = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }
    }

    for (let i = 0; i < 120; i++) particles.push(new Particle());

    /* Central radial glow */
    function drawCenterGlow(t) {
        const cx = W / 2, cy = H / 2;
        const pulse = 0.7 + 0.3 * Math.sin(t * 0.001);

        const g1 = ctx.createRadialGradient(cx, cy, 0, cx, cy, 380 * pulse);
        g1.addColorStop(0,   'rgba(0, 245, 255, 0.06)');
        g1.addColorStop(0.5, 'rgba(255, 0, 200, 0.03)');
        g1.addColorStop(1,   'transparent');
        ctx.fillStyle = g1;
        ctx.fillRect(0, 0, W, H);

        const g2 = ctx.createRadialGradient(cx, cy, 0, cx, cy, 200 * pulse);
        g2.addColorStop(0,   'rgba(0, 245, 255, 0.04)');
        g2.addColorStop(1,   'transparent');
        ctx.fillStyle = g2;
        ctx.fillRect(0, 0, W, H);
    }

    let lastT = 0;
    function animate(t) {
        ctx.clearRect(0, 0, W, H);

        /* Dark background with subtle gradient */
        const bg = ctx.createLinearGradient(0, 0, W, H);
        bg.addColorStop(0,   '#020010');
        bg.addColorStop(0.5, '#04001a');
        bg.addColorStop(1,   '#020010');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, W, H);

        drawCenterGlow(t);

        particles.forEach(p => { p.update(); p.draw(); });
        requestAnimationFrame(animate);
    }
    requestAnimationFrame(animate);

    /* ── RIPPLE ON BUTTON ── */
    document.getElementById('submitBtn').addEventListener('click', function(e) {
        const rect = this.getBoundingClientRect();
        const ripple = document.createElement('span');
        const size = Math.max(rect.width, rect.height);
        ripple.style.cssText = `
            width:${size}px; height:${size}px;
            left:${e.clientX - rect.left - size/2}px;
            top:${e.clientY - rect.top - size/2}px;
        `;
        ripple.classList.add('ripple');
        this.appendChild(ripple);
        setTimeout(() => ripple.remove(), 700);
    });
    </script>
</body>
</html>
