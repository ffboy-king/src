<?php

include('conn.php');
include('mail.php');
include('UserMail.php');

// For Credits
$sql = "SELECT * FROM credit where id=1";
$result = mysqli_query($conn, $sql);
$credit = mysqli_fetch_assoc($result);

// For Keys count
$sql = "SELECT COUNT(*) as id_keys FROM keys_code";
$result = mysqli_query($conn, $sql);
$keycount = mysqli_fetch_assoc($result);

// For Active Keys count
$sql = "SELECT COUNT(devices) as devices FROM keys_code";
$result = mysqli_query($conn, $sql);
$active = mysqli_fetch_assoc($result);

// For In-Active Keys Count
$sql = "SELECT COUNT(*) as devices FROM keys_code where devices IS NULL";
$result = mysqli_query($conn, $sql);
$inactive = mysqli_fetch_assoc($result);

// For Users Count
$sql = "SELECT COUNT(*) as id_users FROM users";
$result = mysqli_query($conn, $sql);
$users = mysqli_fetch_assoc($result);

$userid = session()->userid;
$sql = "SELECT `expiration_date` FROM `users` WHERE `id_users` = '".$userid."'";
$query = mysqli_query($conn, $sql);
$period = mysqli_fetch_assoc($query);

function HoursToDays($value)
{
    if($value == 1) {
       return "$value Hour";
    } else if($value >= 2 && $value < 24) {
       return "$value Hours";
    } else if($value == 24) {
       $darkespyt = $value/24;
       return "$darkespyt Day";
    } else if($value > 24) {
       $darkespyt = $value/24;
       return "$darkespyt Days";
    }
}

$dateTime = strtotime($period['expiration_date']);
$getDateTime = date("F d, Y H:i:s", $dateTime);
?>

<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600;700&display=swap" rel="stylesheet">
<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    :root {
        --cyan:    #00f5ff;
        --magenta: #ff00c8;
        --gold:    #ffd700;
        --dark:    #020010;
        --card-bg: rgba(0, 5, 30, 0.75);
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
        min-height: 100vh;
        background: var(--dark);
        font-family: 'Rajdhani', sans-serif;
        overflow-x: hidden;
        color: #fff;
    }

    /* ── CANVAS BACKGROUND ── */
    #bgCanvas {
        position: fixed;
        inset: 0;
        z-index: 0;
        pointer-events: none;
    }

    /* ── SCAN LINE EFFECT ── */
    .scanlines {
        position: fixed;
        inset: 0;
        z-index: 1;
        pointer-events: none;
        background: repeating-linear-gradient(
            to bottom,
            transparent 0px,
            transparent 3px,
            rgba(0, 245, 255, 0.015) 3px,
            rgba(0, 245, 255, 0.015) 4px
        );
    }

    /* ── ROTATING GLOW RINGS ── */
    .glow-ring {
        position: fixed;
        border-radius: 50%;
        pointer-events: none;
        z-index: 1;
    }
    .ring-1 {
        width: 900px; height: 900px;
        top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        border: 2px solid rgba(0, 245, 255, 0.07);
        box-shadow: 0 0 40px rgba(0, 245, 255, 0.12), inset 0 0 40px rgba(0, 245, 255, 0.03);
        animation: rotateRing 18s linear infinite;
    }
    .ring-2 {
        width: 650px; height: 650px;
        top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        border: 1.5px solid rgba(255, 0, 200, 0.1);
        box-shadow: 0 0 30px rgba(255, 0, 200, 0.1), inset 0 0 30px rgba(255, 0, 200, 0.03);
        animation: rotateRing 10s linear infinite reverse;
    }
    .ring-3 {
        width: 1100px; height: 1100px;
        top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        border: 1px solid rgba(255, 215, 0, 0.05);
        box-shadow: 0 0 60px rgba(255, 215, 0, 0.06);
        animation: rotateRing 25s linear infinite;
    }

    @keyframes rotateRing {
        from { transform: translate(-50%, -50%) rotate(0deg); }
        to   { transform: translate(-50%, -50%) rotate(360deg); }
    }

    /* ── FORCE FULL WIDTH (override Starter layout sidebar) ── */
    @media (max-width: 1024px) {
        .main-content,
        .page-content,
        .content-wrapper,
        .main-wrapper,
        .wrapper,
        #content,
        #main,
        #main-content,
        .container,
        .container-fluid {
            width: 100% !important;
            max-width: 100% !important;
            padding-left: 0 !important;
            padding-right: 0 !important;
            margin-left: 0 !important;
            margin-right: 0 !important;
            float: none !important;
        }
    }

    /* ── MAIN LAYOUT ── */
    .dashboard-wrap {
        position: relative;
        z-index: 10;
        padding: 1rem;
        max-width: 1400px;
        margin: 0 auto;
        width: 100%;
        box-sizing: border-box;
    }

    @media (max-width: 1024px) {
        .dashboard-wrap {
            padding: 0.75rem;
        }
    }

    /* ── PAGE HEADER ── */
    .page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 2rem;
        flex-wrap: wrap;
        gap: 1rem;
        animation: cardIn 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards;
        opacity: 0;
    }

    .page-title {
        font-family: 'Orbitron', monospace;
        font-size: 1.6rem;
        font-weight: 900;
        letter-spacing: 3px;
        background: linear-gradient(90deg, var(--cyan), var(--magenta), var(--gold));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .page-sub {
        font-size: 0.78rem;
        letter-spacing: 2px;
        color: rgba(255,255,255,0.4);
        text-transform: uppercase;
        margin-top: 0.2rem;
    }

    .header-badge {
        font-family: 'Orbitron', monospace;
        font-size: 0.7rem;
        letter-spacing: 2px;
        color: var(--gold);
        border: 1px solid rgba(255,215,0,0.3);
        padding: 0.4rem 1rem;
        border-radius: 30px;
        background: rgba(255,215,0,0.05);
        box-shadow: 0 0 15px rgba(255,215,0,0.1);
    }

    @keyframes cardIn {
        from { opacity: 0; transform: translateY(20px) scale(0.98); }
        to   { opacity: 1; transform: translateY(0) scale(1); }
    }

    /* ── CYBER CARD ── */
    .cyber-card {
        background: var(--card-bg);
        border: 1px solid rgba(0, 245, 255, 0.15);
        border-radius: 16px;
        backdrop-filter: blur(20px);
        box-shadow:
            0 0 0 1px rgba(0,245,255,0.04),
            0 0 30px rgba(0,245,255,0.06),
            0 0 60px rgba(255,0,200,0.03),
            0 20px 40px rgba(0,0,0,0.5);
        position: relative;
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        opacity: 0;
    }

    .cyber-card:hover {
        transform: translateY(-4px);
        box-shadow:
            0 0 0 1px rgba(0,245,255,0.1),
            0 0 40px rgba(0,245,255,0.12),
            0 0 80px rgba(255,0,200,0.06),
            0 25px 50px rgba(0,0,0,0.6);
    }

    /* Corner accents on cards */
    .cyber-card::before,
    .cyber-card::after {
        content: '';
        position: absolute;
        width: 24px; height: 24px;
        border-color: var(--cyan);
        border-style: solid;
        pointer-events: none;
        z-index: 2;
    }
    .cyber-card::before {
        top: -1px; left: -1px;
        border-width: 2px 0 0 2px;
        border-radius: 16px 0 0 0;
        opacity: 0.6;
    }
    .cyber-card::after {
        bottom: -1px; right: -1px;
        border-width: 0 2px 2px 0;
        border-radius: 0 0 16px 0;
        opacity: 0.6;
    }

    /* Card inner glow on hover */
    .cyber-card .card-inner-glow {
        position: absolute;
        inset: 0;
        background: linear-gradient(135deg, rgba(0,245,255,0.03), transparent 60%);
        pointer-events: none;
        z-index: 1;
    }

    .cyber-card .card-body {
        position: relative;
        z-index: 2;
        padding: 1.5rem;
    }

    /* Animation delays */
    .delay-1 { animation: cardIn 0.6s 0.1s cubic-bezier(0.22,1,0.36,1) forwards; }
    .delay-2 { animation: cardIn 0.6s 0.2s cubic-bezier(0.22,1,0.36,1) forwards; }
    .delay-3 { animation: cardIn 0.6s 0.3s cubic-bezier(0.22,1,0.36,1) forwards; }
    .delay-4 { animation: cardIn 0.6s 0.4s cubic-bezier(0.22,1,0.36,1) forwards; }
    .delay-5 { animation: cardIn 0.6s 0.5s cubic-bezier(0.22,1,0.36,1) forwards; }
    .delay-6 { animation: cardIn 0.6s 0.6s cubic-bezier(0.22,1,0.36,1) forwards; }
    .delay-7 { animation: cardIn 0.6s 0.7s cubic-bezier(0.22,1,0.36,1) forwards; }

    /* ── STATS GRID ── */
    .stats-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 1rem;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    @media (min-width: 900px) {
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (min-width: 1200px) {
        .stats-grid {
            grid-template-columns: repeat(4, 1fr);
        }
    }

    /* Ensure stat cards are always full width of their column */
    .stat-card {
        width: 100%;
        min-width: 0;
    }

    .stat-card .card-body {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
    }

    .stat-label {
        font-size: 0.72rem;
        letter-spacing: 2px;
        text-transform: uppercase;
        color: rgba(255,255,255,0.45);
        margin-bottom: 0.4rem;
    }

    .stat-value {
        font-family: 'Orbitron', monospace;
        font-size: 2.2rem;
        font-weight: 700;
        line-height: 1;
    }

    .stat-icon {
        width: 54px; height: 54px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .stat-icon svg { width: 26px; height: 26px; }

    .icon-cyan {
        background: rgba(0,245,255,0.1);
        border: 1px solid rgba(0,245,255,0.25);
        box-shadow: 0 0 20px rgba(0,245,255,0.15);
        color: var(--cyan);
    }

    .icon-magenta {
        background: rgba(255,0,200,0.1);
        border: 1px solid rgba(255,0,200,0.25);
        box-shadow: 0 0 20px rgba(255,0,200,0.15);
        color: var(--magenta);
    }

    .icon-gold {
        background: rgba(255,215,0,0.1);
        border: 1px solid rgba(255,215,0,0.25);
        box-shadow: 0 0 20px rgba(255,215,0,0.15);
        color: var(--gold);
    }

    .icon-purple {
        background: rgba(123,97,255,0.1);
        border: 1px solid rgba(123,97,255,0.25);
        box-shadow: 0 0 20px rgba(123,97,255,0.15);
        color: #7b61ff;
    }

    .val-cyan    { color: var(--cyan); }
    .val-magenta { color: var(--magenta); }
    .val-gold    { color: var(--gold); }
    .val-purple  { color: #7b61ff; }

    /* ── MAIN CONTENT GRID ── */
    .content-grid {
        display: grid;
        grid-template-columns: 1fr 340px;
        gap: 1.5rem;
    }

    @media (max-width: 1024px) {
        .content-grid { grid-template-columns: 1fr; }
    }

    /* ── SECTION HEADER ── */
    .section-header {
        display: flex;
        align-items: center;
        gap: 0.8rem;
        margin-bottom: 1.5rem;
    }

    .section-icon {
        width: 38px; height: 38px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .section-icon svg { width: 20px; height: 20px; }

    .section-title {
        font-family: 'Orbitron', monospace;
        font-size: 0.9rem;
        font-weight: 700;
        letter-spacing: 2px;
        text-transform: uppercase;
    }

    .section-line {
        flex: 1;
        height: 1px;
        background: linear-gradient(90deg, rgba(0,245,255,0.3), transparent);
    }

    /* ── EXPIRY TIMER ── */
    #exp {
        font-family: 'Orbitron', monospace;
        font-weight: 700;
        font-size: clamp(1.2rem, 4vw, 2rem);
        background: linear-gradient(90deg, var(--cyan), var(--magenta), var(--gold));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-align: center;
        letter-spacing: 2px;
        animation: pulseTxt 2s ease-in-out infinite;
    }

    @keyframes pulseTxt {
        0%, 100% { filter: brightness(1); }
        50%       { filter: brightness(1.3) drop-shadow(0 0 8px rgba(0,245,255,0.5)); }
    }

    .timer-wrap {
        padding: 1.5rem 0;
        text-align: center;
    }

    .timer-note {
        font-size: 0.7rem;
        letter-spacing: 2px;
        text-transform: uppercase;
        color: rgba(255,255,255,0.3);
        margin-bottom: 1rem;
    }

    /* ── CHART CONTAINERS ── */
    .chart-container {
        position: relative;
        height: 220px;
    }

    /* ── TABLE ── */
    .cyber-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.85rem;
    }

    .cyber-table thead tr {
        border-bottom: 1px solid rgba(0,245,255,0.15);
    }

    .cyber-table th {
        padding: 0.75rem 1rem;
        text-align: left;
        font-family: 'Orbitron', monospace;
        font-size: 0.65rem;
        letter-spacing: 2px;
        text-transform: uppercase;
        color: var(--cyan);
        font-weight: 400;
    }

    .cyber-table tbody tr {
        border-bottom: 1px solid rgba(255,255,255,0.04);
        transition: background 0.2s;
    }

    .cyber-table tbody tr:hover {
        background: rgba(0,245,255,0.04);
    }

    .cyber-table td {
        padding: 0.75rem 1rem;
        color: rgba(255,255,255,0.75);
        vertical-align: middle;
    }

    .badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.65rem;
        border-radius: 20px;
        font-size: 0.72rem;
        font-family: 'Orbitron', monospace;
        letter-spacing: 1px;
        font-weight: 400;
    }

    .badge-cyan    { background: rgba(0,245,255,0.1);  color: var(--cyan);    border: 1px solid rgba(0,245,255,0.25); }
    .badge-magenta { background: rgba(255,0,200,0.1);  color: var(--magenta); border: 1px solid rgba(255,0,200,0.25); }
    .badge-gold    { background: rgba(255,215,0,0.1);  color: var(--gold);    border: 1px solid rgba(255,215,0,0.25); }
    .badge-purple  { background: rgba(123,97,255,0.1); color: #7b61ff;        border: 1px solid rgba(123,97,255,0.25);}
    .badge-gray    { background: rgba(255,255,255,0.06); color: rgba(255,255,255,0.55); border: 1px solid rgba(255,255,255,0.1); }

    /* ── USER INFO ROW ── */
    .info-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0.85rem 1rem;
        border-radius: 10px;
        background: rgba(0,245,255,0.03);
        border: 1px solid rgba(0,245,255,0.08);
        margin-bottom: 0.75rem;
        transition: background 0.2s, border-color 0.2s;
    }

    .info-row:hover {
        background: rgba(0,245,255,0.06);
        border-color: rgba(0,245,255,0.18);
    }

    .info-row:last-child { margin-bottom: 0; }

    .info-key {
        font-size: 0.72rem;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: rgba(255,255,255,0.4);
    }

    .info-val {
        font-family: 'Orbitron', monospace;
        font-size: 0.78rem;
        letter-spacing: 1px;
    }

    /* ── DIVIDER ── */
    .cyber-divider {
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(0,245,255,0.2), transparent);
        margin: 1.25rem 0;
    }

    /* ── MSG STATUS ── */
    .msg-status-wrap {
        margin-bottom: 1.5rem;
        animation: cardIn 0.4s cubic-bezier(0.22,1,0.36,1) forwards;
    }

    /* ── FOOTER NOTE ── */
    .footer-note {
        text-align: center;
        margin-top: 2rem;
        padding-bottom: 1rem;
    }

    .footer-note p {
        font-size: 0.72rem;
        color: rgba(255,215,0,0.5);
        letter-spacing: 1.5px;
    }

    .footer-note a {
        color: var(--gold);
        font-weight: 700;
        text-decoration: none;
        transition: text-shadow 0.2s;
    }

    .footer-note a:hover { text-shadow: 0 0 10px var(--gold); }

    /* ── OVERFLOW ── */
    .overflow-x-auto { overflow-x: auto; }

    /* ── RESPONSIVE ── */
    @media (max-width: 600px) {
        .page-title { font-size: 1.1rem; }
        .stat-value { font-size: 1.6rem; }
    }

    @media (max-width: 380px) {
        .stat-value { font-size: 1.4rem; }
    }
</style>

<!-- Particle canvas + scan lines -->
<canvas id="bgCanvas"></canvas>
<div class="scanlines"></div>

<!-- Glow rings (subtle, dashboard-scale) -->
<div class="glow-ring ring-1"></div>
<div class="glow-ring ring-2"></div>
<div class="glow-ring ring-3"></div>

<!-- DASHBOARD WRAP -->
<div class="dashboard-wrap">

    <!-- Message Status -->
    <div class="msg-status-wrap">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <!-- Page Header -->
    <div class="page-header" style="animation: cardIn 0.6s cubic-bezier(0.22,1,0.36,1) forwards; opacity:0;">
        <div>
            <div class="page-title">DASHBOARD</div>
            <div class="page-sub">System Overview &amp; Control Panel</div>
        </div>
        <div class="header-badge">&#9679; LIVE</div>
    </div>

    <!-- ── STATS CARDS ── -->
    <div class="stats-grid">

        <!-- Total Keys -->
        <div class="cyber-card stat-card delay-1">
            <div class="card-inner-glow"></div>
            <div class="card-body">
                <div>
                    <div class="stat-label">Total Keys</div>
                    <div class="stat-value val-cyan"><?php echo $keycount['id_keys']; ?></div>
                </div>
                <div class="stat-icon icon-cyan">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                    </svg>
                </div>
            </div>
        </div>

        <!-- Used Keys -->
        <div class="cyber-card stat-card delay-2">
            <div class="card-inner-glow"></div>
            <div class="card-body">
                <div>
                    <div class="stat-label">Used Keys</div>
                    <div class="stat-value val-cyan" style="color:#00ff9d;"><?php echo $active['devices']; ?></div>
                </div>
                <div class="stat-icon" style="background:rgba(0,255,157,0.1);border:1px solid rgba(0,255,157,0.25);box-shadow:0 0 20px rgba(0,255,157,0.15);color:#00ff9d;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
            </div>
        </div>

        <!-- Unused Keys -->
        <div class="cyber-card stat-card delay-3">
            <div class="card-inner-glow"></div>
            <div class="card-body">
                <div>
                    <div class="stat-label">Unused Keys</div>
                    <div class="stat-value val-magenta"><?php echo $inactive['devices']; ?></div>
                </div>
                <div class="stat-icon icon-magenta">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                    </svg>
                </div>
            </div>
        </div>

        <!-- Total Users -->
        <div class="cyber-card stat-card delay-4">
            <div class="card-inner-glow"></div>
            <div class="card-body">
                <div>
                    <div class="stat-label">Total Users</div>
                    <div class="stat-value val-purple"><?php echo $users['id_users']; ?></div>
                </div>
                <div class="stat-icon icon-purple">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                    </svg>
                </div>
            </div>
        </div>

    </div><!-- /stats-grid -->

    <!-- ── MAIN CONTENT ── -->
    <div class="content-grid">

        <!-- Left Column -->
        <div style="display:flex; flex-direction:column; gap:1.5rem;">

            <!-- Expiry Timer -->
            <div class="cyber-card delay-3">
                <div class="card-inner-glow"></div>
                <div class="card-body">
                    <div class="section-header">
                        <div class="section-icon icon-gold">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                        <span class="section-title" style="color:var(--gold);">Subscription Expiry</span>
                        <div class="section-line" style="background:linear-gradient(90deg,rgba(255,215,0,0.3),transparent);"></div>
                    </div>
                    <div class="timer-wrap">
                        <div class="timer-note">Time Remaining</div>
                        <div id="exp"></div>
                    </div>
                </div>
            </div>

            <!-- Keys Chart -->
            <div class="cyber-card delay-4">
                <div class="card-inner-glow"></div>
                <div class="card-body">
                    <div class="section-header">
                        <div class="section-icon icon-cyan">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                            </svg>
                        </div>
                        <span class="section-title" style="color:var(--cyan);">Keys Overview</span>
                        <div class="section-line"></div>
                    </div>
                    <div class="chart-container">
                        <canvas id="keysChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- History Table -->
            <div class="cyber-card delay-5">
                <div class="card-inner-glow"></div>
                <div class="card-body">
                    <div class="section-header">
                        <div class="section-icon icon-magenta">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                        <span class="section-title" style="color:var(--magenta);">Recent History</span>
                        <div class="section-line" style="background:linear-gradient(90deg,rgba(255,0,200,0.3),transparent);"></div>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="cyber-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Type</th>
                                    <th>Code</th>
                                    <th>Duration</th>
                                    <th>Devices</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($history as $h) : ?>
                                    <?php $in = explode("|", $h->info) ?>
                                    <tr>
                                        <td><span class="badge badge-gray">#3812<?= $h->id_history ?></span></td>
                                        <td><?= $in[0] ?></td>
                                        <td><span class="badge badge-cyan"><?= $in[1] ?>**</span></td>
                                        <td><span class="badge badge-gold"><?= HoursToDays($in[2]); ?></span></td>
                                        <td><span class="badge badge-purple"><?= $in[3] ?> Devices</span></td>
                                        <td style="color:rgba(255,255,255,0.4); font-size:0.8rem;"><?= $time::parse($h->created_at)->humanize() ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div><!-- /left col -->

        <!-- Right Column -->
        <div style="display:flex; flex-direction:column; gap:1.5rem;">

            <!-- User Info -->
            <div class="cyber-card delay-4">
                <div class="card-inner-glow"></div>
                <div class="card-body">
                    <div class="section-header">
                        <div class="section-icon" style="background:rgba(0,255,157,0.1);border:1px solid rgba(0,255,157,0.25);color:#00ff9d;">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                            </svg>
                        </div>
                        <span class="section-title" style="color:#00ff9d;">User Info</span>
                        <div class="section-line" style="background:linear-gradient(90deg,rgba(0,255,157,0.3),transparent);"></div>
                    </div>

                    <div class="info-row">
                        <span class="info-key">Role</span>
                        <span class="info-val" style="color:var(--cyan);"><?= getLevel($user->level) ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-key">Balance</span>
                        <span class="info-val" style="color:#00ff9d;">₹<?= $user->saldo ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-key">Login Time</span>
                        <span class="info-val" style="color:var(--magenta);"><?= $time::parse(session()->time_since)->humanize() ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-key">Auto Logout</span>
                        <span class="info-val" style="color:var(--gold);"><?= $time::now()->difference($time::parse(session()->time_login))->humanize() ?></span>
                    </div>
                </div>
            </div>

            <!-- Doughnut Chart -->
            <div class="cyber-card delay-5">
                <div class="card-inner-glow"></div>
                <div class="card-body">
                    <div class="section-header">
                        <div class="section-icon icon-purple">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"/>
                            </svg>
                        </div>
                        <span class="section-title" style="color:#7b61ff;">Key Distribution</span>
                        <div class="section-line" style="background:linear-gradient(90deg,rgba(123,97,255,0.3),transparent);"></div>
                    </div>
                    <div class="chart-container" style="height:200px;">
                        <canvas id="doughnutChart"></canvas>
                    </div>
                </div>
            </div>

        </div><!-- /right col -->

    </div><!-- /content-grid -->

    <!-- Footer -->
    <div class="footer-note">
        <p>TO BUY PANEL DM :-
            <a href="https://t.me/Rohan_Moder/s" target="_blank">@Rohan_Moder</a>
        </p>
    </div>

</div><!-- /dashboard-wrap -->

<script>
/* ── PARTICLE CANVAS ── */
const canvas = document.getElementById('bgCanvas');
const ctx0   = canvas.getContext('2d');
let W, H, particles = [];

function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
}
resize();
window.addEventListener('resize', resize);

const COLORS = ['#00f5ff', '#ff00c8', '#ffd700', '#7b61ff', '#00ff9d'];

function rand(a, b) { return Math.random() * (b - a) + a; }

class Particle {
    constructor() { this.reset(true); }
    reset(init) {
        this.x      = rand(0, W);
        this.y      = init ? rand(0, H) : H + 10;
        this.vy     = rand(-0.3, -1.0);
        this.vx     = rand(-0.15, 0.15);
        this.r      = rand(0.8, 2.2);
        this.color  = COLORS[Math.floor(Math.random() * COLORS.length)];
        this.alpha  = rand(0.2, 0.7);
        this.life   = 0;
        this.maxLife = rand(180, 400);
    }
    update() {
        this.x += this.vx; this.y += this.vy; this.life++;
        if (this.life > this.maxLife || this.y < -10) this.reset(false);
    }
    draw() {
        ctx0.save();
        ctx0.globalAlpha = this.alpha * (1 - this.life / this.maxLife);
        ctx0.fillStyle   = this.color;
        ctx0.shadowBlur  = 6;
        ctx0.shadowColor = this.color;
        ctx0.beginPath();
        ctx0.arc(this.x, this.y, this.r, 0, Math.PI * 2);
        ctx0.fill();
        ctx0.restore();
    }
}

for (let i = 0; i < 100; i++) particles.push(new Particle());

function drawCenterGlow(t) {
    const cx = W / 2, cy = H / 2;
    const pulse = 0.7 + 0.3 * Math.sin(t * 0.001);
    const g1 = ctx0.createRadialGradient(cx, cy, 0, cx, cy, 450 * pulse);
    g1.addColorStop(0,   'rgba(0,245,255,0.04)');
    g1.addColorStop(0.5, 'rgba(255,0,200,0.02)');
    g1.addColorStop(1,   'transparent');
    ctx0.fillStyle = g1;
    ctx0.fillRect(0, 0, W, H);
}

function animate(t) {
    ctx0.clearRect(0, 0, W, H);
    const bg = ctx0.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0,   '#020010');
    bg.addColorStop(0.5, '#04001a');
    bg.addColorStop(1,   '#020010');
    ctx0.fillStyle = bg;
    ctx0.fillRect(0, 0, W, H);
    drawCenterGlow(t);
    particles.forEach(p => { p.update(); p.draw(); });
    requestAnimationFrame(animate);
}
requestAnimationFrame(animate);

/* ── COUNTDOWN TIMER ── */
var countDownTimer = new Date("<?php echo "$getDateTime"; ?>").getTime();
var interval = setInterval(function() {
    var current = new Date().getTime();
    var diff    = countDownTimer - current;
    var days    = Math.floor(diff / (1000 * 60 * 60 * 24));
    var hours   = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((diff % (1000 * 60)) / 1000);
    document.getElementById("exp").innerHTML =
        days + "d : " + hours + "h : " + minutes + "m : " + seconds + "s";
    if (diff < 0) {
        clearInterval(interval);
        document.getElementById("exp").innerHTML = "EXPIRED";
        document.getElementById("exp").style.color = "#ff4d6d";
        document.getElementById("exp").style.webkitTextFillColor = "#ff4d6d";
    }
}, 1000);

/* ── CHART DEFAULTS ── */
Chart.defaults.color = 'rgba(255,255,255,0.45)';
Chart.defaults.borderColor = 'rgba(255,255,255,0.06)';
Chart.defaults.font.family = "'Rajdhani', sans-serif";

/* ── BAR CHART ── */
const ctx1 = document.getElementById('keysChart').getContext('2d');
new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: ['Total Keys', 'Used Keys', 'Unused Keys'],
        datasets: [{
            label: 'Keys',
            data: [
                <?php echo $keycount['id_keys']; ?>,
                <?php echo $active['devices']; ?>,
                <?php echo $inactive['devices']; ?>
            ],
            backgroundColor: [
                'rgba(0, 245, 255, 0.25)',
                'rgba(0, 255, 157, 0.25)',
                'rgba(255, 0, 200, 0.25)'
            ],
            borderColor: [
                'rgba(0, 245, 255, 0.9)',
                'rgba(0, 255, 157, 0.9)',
                'rgba(255, 0, 200, 0.9)'
            ],
            borderWidth: 2,
            borderRadius: 8,
            hoverBackgroundColor: [
                'rgba(0, 245, 255, 0.4)',
                'rgba(0, 255, 157, 0.4)',
                'rgba(255, 0, 200, 0.4)'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: {
                beginAtZero: true,
                grid: { color: 'rgba(0,245,255,0.06)' },
                ticks: { color: 'rgba(255,255,255,0.4)', font: { size: 11 } }
            },
            x: {
                grid: { display: false },
                ticks: { color: 'rgba(255,255,255,0.5)', font: { size: 11 } }
            }
        }
    }
});

/* ── DOUGHNUT CHART ── */
const ctx2 = document.getElementById('doughnutChart').getContext('2d');
new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Used Keys', 'Unused Keys'],
        datasets: [{
            data: [<?php echo $active['devices']; ?>, <?php echo $inactive['devices']; ?>],
            backgroundColor: [
                'rgba(0, 255, 157, 0.3)',
                'rgba(255, 0, 200, 0.3)'
            ],
            borderColor: [
                'rgba(0, 255, 157, 0.9)',
                'rgba(255, 0, 200, 0.9)'
            ],
            borderWidth: 2,
            hoverOffset: 6
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 16,
                    color: 'rgba(255,255,255,0.6)',
                    font: { size: 11, family: "'Rajdhani', sans-serif" },
                    boxWidth: 12,
                    borderRadius: 4
                }
            }
        }
    }
});
</script>

<?= $this->endSection() ?>
