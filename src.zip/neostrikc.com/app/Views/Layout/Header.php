<!-- Google Fonts (same as login.php) -->
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
    /* ── HEADER CSS VARIABLES (match login.php) ── */
    :root {
        --cyan:    #00f5ff;
        --magenta: #ff00c8;
        --gold:    #ffd700;
        --dark:    #020010;
        --card-bg: rgba(0, 5, 30, 0.85);
    }

    /* ── HEADER BASE ── */
    .cyber-header {
        position: sticky;
        top: 0;
        z-index: 9999;
        background: var(--card-bg);
        border-bottom: 1px solid rgba(0, 245, 255, 0.2);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        box-shadow:
            0 0 0 1px rgba(0,245,255,0.05),
            0 4px 30px rgba(0, 245, 255, 0.08),
            0 4px 60px rgba(255, 0, 200, 0.05);
        font-family: 'Rajdhani', sans-serif;
    }

    /* Scanline overlay on header */
    .cyber-header::before {
        content: '';
        position: absolute;
        inset: 0;
        background: repeating-linear-gradient(
            0deg,
            transparent,
            transparent 2px,
            rgba(0, 245, 255, 0.015) 2px,
            rgba(0, 245, 255, 0.015) 4px
        );
        pointer-events: none;
        z-index: 0;
    }

    /* Bottom glow line */
    .cyber-header::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: linear-gradient(90deg, transparent, var(--cyan), var(--magenta), var(--gold), transparent);
        animation: glowLine 3s ease-in-out infinite;
    }

    @keyframes glowLine {
        0%, 100% { opacity: 0.4; }
        50%       { opacity: 1; }
    }

    .cyber-nav-inner {
        position: relative;
        z-index: 1;
        max-width: 1280px;
        margin: 0 auto;
        padding: 0 1.5rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 64px;
    }

    /* ── LOGO ── */
    .cyber-logo {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        text-decoration: none;
    }

    .cyber-logo-icon {
        width: 38px;
        height: 38px;
        border: 1.5px solid rgba(0,245,255,0.4);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0,245,255,0.05);
        box-shadow: 0 0 12px rgba(0,245,255,0.2), inset 0 0 8px rgba(0,245,255,0.05);
        transition: box-shadow 0.3s ease;
    }

    .cyber-logo:hover .cyber-logo-icon {
        box-shadow: 0 0 20px rgba(0,245,255,0.4), inset 0 0 12px rgba(0,245,255,0.1);
    }

    .cyber-logo-icon svg {
        width: 20px;
        height: 20px;
        color: var(--cyan);
    }

    .cyber-logo-text {
        font-family: 'Orbitron', monospace;
        font-size: 1.1rem;
        font-weight: 900;
        letter-spacing: 2px;
        background: linear-gradient(90deg, var(--cyan), var(--magenta), var(--gold));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    /* ── DESKTOP NAV LINKS ── */
    .cyber-nav-links {
        display: none;
        align-items: center;
        gap: 0.25rem;
    }

    @media (min-width: 768px) {
        .cyber-nav-links { display: flex; }
    }

    .cyber-nav-link {
        display: flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.45rem 1rem;
        border-radius: 8px;
        text-decoration: none;
        font-family: 'Rajdhani', sans-serif;
        font-weight: 600;
        font-size: 0.95rem;
        letter-spacing: 1px;
        color: rgba(255,255,255,0.6);
        text-transform: uppercase;
        border: 1px solid transparent;
        transition: all 0.25s ease;
        position: relative;
        overflow: hidden;
    }

    .cyber-nav-link svg {
        width: 16px;
        height: 16px;
        flex-shrink: 0;
    }

    .cyber-nav-link:hover {
        color: var(--cyan);
        border-color: rgba(0,245,255,0.3);
        background: rgba(0,245,255,0.06);
        box-shadow: 0 0 12px rgba(0,245,255,0.15), inset 0 0 8px rgba(0,245,255,0.04);
        text-shadow: 0 0 8px rgba(0,245,255,0.5);
    }

    /* ── USER DROPDOWN BUTTON ── */
    .cyber-user-wrap {
        position: relative;
        display: none;
    }

    @media (min-width: 768px) {
        .cyber-user-wrap { display: block; }
    }

    .cyber-user-btn {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.4rem 0.9rem;
        border-radius: 8px;
        background: rgba(0,245,255,0.05);
        border: 1px solid rgba(0,245,255,0.2);
        color: rgba(255,255,255,0.75);
        font-family: 'Rajdhani', sans-serif;
        font-weight: 600;
        font-size: 0.9rem;
        letter-spacing: 1px;
        cursor: pointer;
        transition: all 0.25s ease;
    }

    .cyber-user-btn:hover {
        border-color: rgba(0,245,255,0.5);
        box-shadow: 0 0 14px rgba(0,245,255,0.2);
        color: var(--cyan);
    }

    .cyber-user-avatar {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--cyan), var(--magenta));
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 0 8px rgba(0,245,255,0.3);
    }

    .cyber-user-avatar svg {
        width: 16px;
        height: 16px;
        color: #fff;
    }

    .cyber-arrow {
        width: 14px;
        height: 14px;
        transition: transform 0.3s ease;
    }

    .cyber-arrow.open {
        transform: rotate(180deg);
    }

    /* ── DROPDOWN MENU ── */
    .cyber-dropdown {
        display: none;
        position: absolute;
        right: 0;
        top: calc(100% + 10px);
        width: 220px;
        background: rgba(2, 0, 20, 0.97);
        border: 1px solid rgba(0,245,255,0.25);
        border-radius: 14px;
        backdrop-filter: blur(20px);
        box-shadow:
            0 0 0 1px rgba(0,245,255,0.05),
            0 10px 40px rgba(0,0,0,0.7),
            0 0 30px rgba(0,245,255,0.08);
        overflow: hidden;
        animation: dropIn 0.2s ease forwards;
    }

    .cyber-dropdown.open {
        display: block;
    }

    @keyframes dropIn {
        from { opacity: 0; transform: translateY(-8px); }
        to   { opacity: 1; transform: translateY(0); }
    }

    /* Dropdown top accent line */
    .cyber-dropdown::before {
        content: '';
        display: block;
        height: 2px;
        background: linear-gradient(90deg, var(--cyan), var(--magenta));
    }

    .cyber-dropdown-item {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        padding: 0.7rem 1.1rem;
        text-decoration: none;
        font-family: 'Rajdhani', sans-serif;
        font-weight: 600;
        font-size: 0.9rem;
        letter-spacing: 0.5px;
        color: rgba(255,255,255,0.55);
        text-transform: uppercase;
        transition: all 0.2s ease;
        border-bottom: 1px solid rgba(0,245,255,0.05);
    }

    .cyber-dropdown-item svg {
        width: 16px;
        height: 16px;
        flex-shrink: 0;
    }

    .cyber-dropdown-item:hover {
        background: rgba(0,245,255,0.06);
        color: var(--cyan);
    }

    .cyber-dropdown-item:hover svg {
        filter: drop-shadow(0 0 4px var(--cyan));
    }

    .cyber-dropdown-item.danger {
        color: rgba(255, 80, 80, 0.7);
    }

    .cyber-dropdown-item.danger:hover {
        background: rgba(255,0,80,0.06);
        color: #ff5555;
    }

    .cyber-dropdown-item.danger:hover svg {
        filter: drop-shadow(0 0 4px #ff5555);
    }

    .cyber-divider {
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(0,245,255,0.2), transparent);
        margin: 0.25rem 0;
    }

    /* ── MOBILE HAMBURGER ── */
    .cyber-hamburger {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 8px;
        border: 1px solid rgba(0,245,255,0.2);
        background: rgba(0,245,255,0.05);
        color: var(--cyan);
        cursor: pointer;
        transition: all 0.25s ease;
    }

    .cyber-hamburger:hover {
        border-color: rgba(0,245,255,0.5);
        box-shadow: 0 0 12px rgba(0,245,255,0.2);
    }

    .cyber-hamburger svg {
        width: 20px;
        height: 20px;
    }

    @media (min-width: 768px) {
        .cyber-hamburger { display: none; }
    }

    /* ── MOBILE MENU ── */
    .cyber-mobile-menu {
        display: none;
        position: relative;
        z-index: 1;
        border-top: 1px solid rgba(0,245,255,0.1);
        padding: 0.75rem 1.5rem;
        background: rgba(0,0,10,0.6);
    }

    .cyber-mobile-menu.open {
        display: block;
    }

    .cyber-mobile-link {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        padding: 0.65rem 0.75rem;
        border-radius: 8px;
        text-decoration: none;
        font-family: 'Rajdhani', sans-serif;
        font-weight: 600;
        font-size: 0.95rem;
        letter-spacing: 0.5px;
        color: rgba(255,255,255,0.55);
        text-transform: uppercase;
        transition: all 0.2s ease;
        margin-bottom: 0.15rem;
    }

    .cyber-mobile-link svg {
        width: 17px;
        height: 17px;
        flex-shrink: 0;
    }

    .cyber-mobile-link:hover {
        background: rgba(0,245,255,0.07);
        color: var(--cyan);
    }

    .cyber-mobile-link.danger {
        color: rgba(255,80,80,0.7);
    }

    .cyber-mobile-link.danger:hover {
        background: rgba(255,0,80,0.07);
        color: #ff5555;
    }

    .cyber-mobile-divider {
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(0,245,255,0.2), transparent);
        margin: 0.4rem 0;
    }
</style>

<header class="cyber-header">
    <div class="cyber-nav-inner">

        <!-- ── LOGO ── -->
        <a href="<?= site_url() ?>" class="cyber-logo">
            <div class="cyber-logo-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                </svg>
            </div>
            <span class="cyber-logo-text"><?= BASE_NAME ?></span>
        </a>

        <?php if (session()->has('userid')) : ?>

            <!-- ── DESKTOP NAV LINKS ── -->
            <nav class="cyber-nav-links">
                <a href="<?= site_url('keys') ?>" class="cyber-nav-link">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                    </svg>
                    Keys
                </a>
                <a href="<?= site_url('keys/generate') ?>" class="cyber-nav-link">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                    </svg>
                    Generate
                </a>
            </nav>

            <!-- ── DESKTOP USER DROPDOWN ── -->
            <div class="cyber-user-wrap">
                <button class="cyber-user-btn" id="cyber-user-btn">
                    <div class="cyber-user-avatar">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                        </svg>
                    </div>
                    <?= getName($user) ?>
                    <svg class="cyber-arrow" id="cyber-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                </button>

                <div class="cyber-dropdown" id="cyber-dropdown">
                    <a href="<?= site_url('settings') ?>" class="cyber-dropdown-item">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                        </svg>
                        Settings
                    </a>

                    <?php if (($user->level == 1) || ($user->level == 2)) : ?>
                        <div class="cyber-divider"></div>

                        <a href="<?= site_url('Server') ?>" class="cyber-dropdown-item">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01"/>
                            </svg>
                            Online System
                        </a>

                        <a href="<?= site_url('admin/manage-users') ?>" class="cyber-dropdown-item">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                            </svg>
                            Manage Users
                        </a>

                        <a href="<?= site_url('admin/create-referral') ?>" class="cyber-dropdown-item">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                            </svg>
                            Create Referral
                        </a>

                        <div class="cyber-divider"></div>
                    <?php endif; ?>

                    <a href="<?= site_url('logout') ?>" class="cyber-dropdown-item danger">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                        </svg>
                        Logout
                    </a>
                </div>
            </div>

            <!-- ── MOBILE HAMBURGER ── -->
            <button class="cyber-hamburger" id="cyber-hamburger">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>

        <?php endif; ?>
    </div>

    <!-- ── MOBILE MENU ── -->
    <?php if (session()->has('userid')) : ?>
        <div class="cyber-mobile-menu" id="cyber-mobile-menu">
            <a href="<?= site_url('keys') ?>" class="cyber-mobile-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                </svg>
                Keys
            </a>
            <a href="<?= site_url('keys/generate') ?>" class="cyber-mobile-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                </svg>
                Generate
            </a>

            <div class="cyber-mobile-divider"></div>

            <a href="<?= site_url('settings') ?>" class="cyber-mobile-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                Settings
            </a>

            <?php if (($user->level == 1) || ($user->level == 2)) : ?>
                <a href="<?= site_url('Server') ?>" class="cyber-mobile-link">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01"/>
                    </svg>
                    Online System
                </a>

                <a href="<?= site_url('admin/manage-users') ?>" class="cyber-mobile-link">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                    </svg>
                    Manage Users
                </a>

                <a href="<?= site_url('admin/create-referral') ?>" class="cyber-mobile-link">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                    </svg>
                    Create Referral
                </a>

                <div class="cyber-mobile-divider"></div>
            <?php endif; ?>

            <a href="<?= site_url('logout') ?>" class="cyber-mobile-link danger">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
                Logout
            </a>
        </div>
    <?php endif; ?>
</header>

<script>
    // ── DESKTOP DROPDOWN ──
    const cyberBtn      = document.getElementById('cyber-user-btn');
    const cyberDropdown = document.getElementById('cyber-dropdown');
    const cyberArrow    = document.getElementById('cyber-arrow');

    if (cyberBtn && cyberDropdown) {
        cyberBtn.addEventListener('click', () => {
            cyberDropdown.classList.toggle('open');
            cyberArrow.classList.toggle('open');
        });
        document.addEventListener('click', (e) => {
            if (!cyberBtn.contains(e.target) && !cyberDropdown.contains(e.target)) {
                cyberDropdown.classList.remove('open');
                cyberArrow.classList.remove('open');
            }
        });
    }

    // ── MOBILE MENU ──
    const cyberHamburger   = document.getElementById('cyber-hamburger');
    const cyberMobileMenu  = document.getElementById('cyber-mobile-menu');

    if (cyberHamburger && cyberMobileMenu) {
        cyberHamburger.addEventListener('click', () => {
            cyberMobileMenu.classList.toggle('open');
        });
    }
</script>
