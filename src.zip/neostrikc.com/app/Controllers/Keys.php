<?php

namespace App\Controllers;

use App\Models\HistoryModel;
use App\Models\KeysModel;
use App\Models\UserModel;
use Config\Services;

class Keys extends BaseController
{
    protected $userModel, $model, $user;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->user = $this->userModel->getUser();
        $this->model = new KeysModel();
        $this->time = new \CodeIgniter\I18n\Time;

        /* ------- Game ------- */
        $this->game_list = [
            'FreeFire' => 'Free Fire Injector',
        ];

        $this->duration = [
            1  => '1 Day &mdash; 40 Rs',
            3  => '3 Day &mdash; 70 Rs',
            7  => '7 Day &mdash; 130 Rs',
            14 => '14 Day &mdash; 235 Rs',
            28 => '28 Day &mdash; 335 Rs',
            
        ];

        $this->price = [
            1  => 40,
            3  => 70,
            7  => 130,
            14 => 235,
            28 => 335,
        ];
    }

    public function index()
    {
        $model = $this->model;
        $user  = $this->user;

        if ($user->level != 1) {
            $keys = $model->where('registrator', $user->username)->findAll();
        } else {
            $keys = $model->select('user_key')->findAll();
        }

        $data = [
            'title'   => 'Keys',
            'user'    => $user,
            'keylist' => $keys,
            'time'    => $this->time,
        ];
        return view('Keys/list', $data);
    }

    public function download_all_Keys()
    {
        $model = $this->model;
        $keys  = $model->select('user_key')->findAll();
        $data  = '';
        foreach ($keys as $k) {
            $data .= "Key:- " . $k['user_key'] . "\n";
        }
        write_file('newName.txt', $data);
        $this->downloadFile('newName.txt');
    }

    public function download_new_Keys()
    {
        $this->downloadFile('new.txt');
    }

    private function downloadFile($yourFile)
    {
        $file = @fopen($yourFile, "rb");
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=BHATIA PANNEL KEY DOWNLOAD.txt');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($yourFile));
        while (!feof($file)) {
            print(@fread($file, 1024 * 8));
            ob_flush();
            flush();
        }
    }

    public function alterKeys()
    {
        $this->model->where('expired_date <', date('Y-m-d H:i:s'))->delete();
        return redirect()->back()->with('msgSuccess', 'Expired keys deleted successfully.');
    }

    public function deleteKeys()
    {
        $this->model->emptyTable('keys_code');
        return redirect()->back()->with('msgSuccess', 'All keys deleted successfully.');
    }

    public function resetAllKeys()
    {
        $keys = $this->request->getGet('userkey');
        $this->model->where('user_key', $keys)->delete();
        return redirect()->back()->with('msgSuccess', 'Key reset successfully.');
    }

    // Delete keys with no expiry date (unused/blank)
    public function startDate()
    {
        $this->model->where('expired_date IS NULL', null, false)->delete();
        return redirect()->back()->with('msgSuccess', 'Unused keys deleted successfully.');
    }

    public function api_get_keys()
    {
        return $this->model->API_getKeys();
    }

    public function deleteExpired()
    {
        $this->model->where('expired_date <', date('Y-m-d H:i:s'))->delete();
        return redirect()->back()->with('msgSuccess', 'Expired keys deleted successfully.');
    }

    // Delete keys with no expiry date
    public function deleteUnused()
    {
        $this->model->where('expired_date IS NULL', null, false)->delete();
        return redirect()->back()->with('msgSuccess', 'Unused keys deleted successfully.');
    }

    public function api_key_reset()
    {
        sleep(1);
        $model  = $this->model;
        $keys   = $this->request->getGet('userkey');
        $reset  = $this->request->getGet('reset');
        $db_key = $model->getKeys($keys);

        $rules = [];
        if ($db_key) {
            $total = $db_key->devices ? explode(',', $db_key->devices) : [];
            $rules = ['devices_total' => count($total), 'devices_max' => (int) $db_key->max_devices];
            $user  = $this->user;
            if ($db_key->devices && $reset) {
                if ($user->level == 1 || $db_key->registrator == $user->username) {
                    $model->set('devices', NULL)->where('user_key', $keys)->update();
                    $rules = ['reset' => true, 'devices_total' => 0, 'devices_max' => $db_key->max_devices];
                }
            }
        }

        $data = [
            'registered' => $db_key ? true : false,
            'keys'       => $keys,
        ];
        return $this->response->setJSON(array_merge($data, $rules));
    }

    public function edit_key($key = false)
    {
        if ($this->request->getPost()) return $this->edit_key_action();

        $msgDanger = "The user key no longer exists.";
        if ($key) {
            $dKey = $this->model->getKeys($key, 'id_keys');
            $user = $this->user;
            if ($dKey) {
                if ($user->level == 1 || $dKey->registrator == $user->username) {
                    $validation = Services::validation();
                    $data = [
                        'title'      => 'Key',
                        'user'       => $user,
                        'key'        => $dKey,
                        'game_list'  => $this->game_list,
                        'time'       => $this->time,
                        'key_info'   => getDevice($dKey->devices),
                        'messages'   => setMessage('Please carefully edit information'),
                        'validation' => $validation,
                    ];
                    return view('Keys/key_edit', $data);
                } else {
                    $msgDanger = "Restricted to this user key.";
                }
            }
        }
        return redirect()->to('keys')->with('msgDanger', $msgDanger);
    }

    private function edit_key_action()
    {
        $keys  = $this->request->getPost('id_keys');
        $user  = $this->user;
        $dKey  = $this->model->getKeys($keys, 'id_keys');
        $game  = implode(",", array_keys($this->game_list));

        if (!$dKey) {
            $msgDanger = "The user key no longer exists~";
        } else {
            if ($user->level == 1 || $dKey->registrator == $user->username) {
                $form_reseller = [
                    'status' => [
                        'label'  => 'status',
                        'rules'  => 'required|integer|in_list[0,1]',
                        'errors' => [
                            'integer' => 'Invalid {field}.',
                            'in_list' => 'Choose between list.'
                        ]
                    ]
                ];
                $form_admin = [
                    'id_keys' => [
                        'label'  => 'keys',
                        'rules'  => 'required|is_not_unique[keys_code.id_keys]|numeric',
                        'errors' => ['is_not_unique' => 'Invalid keys.'],
                    ],
                    'game' => [
                        'label'  => 'Games',
                        'rules'  => "required|alpha_numeric_space|in_list[$game]",
                        'errors' => ['alpha_numeric_space' => 'Invalid characters.'],
                    ],
                    'user_key' => [
                        'label'  => 'User keys',
                        'rules'  => "required|is_unique[keys_code.user_key,user_key,$dKey->user_key]|alpha_numeric",
                        'errors' => ['is_unique' => '{field} has been taken.'],
                    ],
                    'duration' => [
                        'label'  => 'duration',
                        'rules'  => 'required|numeric|greater_than_equal_to[1]',
                        'errors' => [
                            'greater_than_equal_to' => 'Minimum {field} is invalid.',
                            'numeric'               => 'Invalid hour {field}.'
                        ]
                    ],
                    'max_devices' => [
                        'label'  => 'devices',
                        'rules'  => 'required|numeric|greater_than_equal_to[1]',
                        'errors' => [
                            'greater_than_equal_to' => 'Minimum {field} is invalid.',
                            'numeric'               => 'Invalid max of {field}.'
                        ]
                    ],
                    'registrator' => [
                        'label' => 'registrator',
                        'rules' => 'permit_empty|alpha_numeric_space|min_length[4]'
                    ],
                    'expired_date' => [
                        'label'  => 'expired',
                        'rules'  => 'permit_empty|valid_date[Y-m-d H:i:s]',
                        'errors' => ['valid_date' => 'Invalid {field} date.'],
                    ],
                    'devices' => [
                        'label' => 'device list',
                        'rules' => 'permit_empty'
                    ]
                ];

                if ($user->level == 1) {
                    $form_rules  = array_merge($form_reseller, $form_admin);
                    $devices     = $this->request->getPost('devices');
                    $max_devices = $this->request->getPost('max_devices');
                    $data_saves  = [
                        'game'         => $this->request->getPost('game'),
                        'user_key'     => $this->request->getPost('user_key'),
                        'duration'     => $this->request->getPost('duration'),
                        'max_devices'  => $max_devices,
                        'status'       => $this->request->getPost('status'),
                        'registrator'  => $this->request->getPost('registrator'),
                        'expired_date' => $this->request->getPost('expired_date') ?: NULL,
                        'devices'      => setDevice($devices, $max_devices),
                    ];
                } else {
                    $form_rules = $form_reseller;
                    $data_saves = ['status' => $this->request->getPost('status')];
                }

                if (!$this->validate($form_rules)) {
                    return redirect()->back()->withInput()->with('msgDanger', 'Failed! Please check the error');
                } else {
                    $this->model->update($dKey->id_keys, $data_saves);
                    return redirect()->back()->with('msgSuccess', 'User key successfully updated!');
                }
            } else {
                $msgDanger = "Restricted to this user key~";
            }
        }
        return redirect()->to('keys')->with('msgDanger', $msgDanger);
    }

    public function generate()
    {
        if ($this->request->getPost()) return $this->generate_action();

        $user    = $this->user;
        $validation = Services::validation();

        $message = setMessage("<i class='bi bi-wallet'></i> Total Saldo $$user->saldo");
        if ($user->saldo <= 0) {
            $message = setMessage("Please top up to your beloved admin.", 'warning');
        }

        $data = [
            'title'      => 'Generate',
            'user'       => $user,
            'time'       => $this->time,
            'game'       => $this->game_list,
            'duration'   => $this->duration,
            'price'      => json_encode($this->price),
            'messages'   => $message,
            'validation' => $validation,
        ];
        return view('Keys/generate', $data);
    }

    private function generate_action()
    {
        $user  = $this->user;
        $game  = $this->request->getPost('game');
        $maxd  = (int) $this->request->getPost('max_devices');
        $drtn  = $this->request->getPost('duration');

        // Quantity: direct number from form (1–100), clamp to safe range
        $loopcount = (int) $this->request->getPost('loopcount');
        $loopcount = max(1, min(100, $loopcount)); // clamp between 1 and 100

        // Price per key
        $pricePerKey = getPrice($this->price, $drtn, $maxd);
        // Total cost for all keys
        $totalPrice  = $pricePerKey * $loopcount;

        $game_list  = implode(",", array_keys($this->game_list));
        $form_rules = [
            'game' => [
                'label'  => 'Games',
                'rules'  => "required|alpha_numeric_space|in_list[$game_list]",
                'errors' => ['alpha_numeric_space' => 'Invalid characters.'],
            ],
            'duration' => [
                'label'  => 'duration',
                'rules'  => 'required|numeric|greater_than_equal_to[1]',
                'errors' => [
                    'greater_than_equal_to' => 'Minimum {field} is invalid.',
                    'numeric'               => 'Invalid day {field}.'
                ]
            ],
            'max_devices' => [
                'label'  => 'devices',
                'rules'  => 'required|numeric|greater_than_equal_to[1]',
                'errors' => [
                    'greater_than_equal_to' => 'Minimum {field} is invalid.',
                    'numeric'               => 'Invalid max of {field}.'
                ]
            ],
            'loopcount' => [
                'label'  => 'quantity',
                'rules'  => 'required|numeric|greater_than_equal_to[1]|less_than_equal_to[100]',
                'errors' => [
                    'greater_than_equal_to' => 'Minimum quantity is 1.',
                    'less_than_equal_to'    => 'Maximum quantity is 100.',
                    'numeric'               => 'Invalid quantity.',
                ]
            ],
        ];

        $validation   = Services::validation();
        $reduceCheck  = ($user->saldo - $totalPrice);

        // Check balance for total cost
        if ($reduceCheck < 0) {
            $validation->setError('duration', 'Insufficient balance');
            return redirect()->back()->withInput()->with('msgWarning', 'Insufficient balance! Please top up.');
        }

        if (!$this->validate($form_rules)) {
            return redirect()->back()->withInput()->with('msgDanger', 'Failed! Please check the error.');
        }

        // ---- Generate all keys ----
        $generatedKeys  = [];
        $history        = new HistoryModel();
        $txtData        = '';

        // Step 1: Generate $loopcount unique keys (alphanumeric, not just numeric)
        // Uses alphanumeric to massively reduce collision probability, and
        // double-checks DB before accepting each key.
        $uniqueKeys = [];
        $maxAttempts = $loopcount * 10; // safety ceiling to avoid infinite loop
        $attempts    = 0;

        while (count($uniqueKeys) < $loopcount && $attempts < $maxAttempts) {
            $attempts++;
            // alnum gives 36^12 = ~4.7 trillion combinations — no collisions in practice
            $candidate = strtoupper(random_string('alnum', 12));

            // Skip if already picked in this batch
            if (in_array($candidate, $uniqueKeys)) continue;

            // Skip if already exists in database
            if ($this->model->where('user_key', $candidate)->countAllResults() > 0) continue;

            $uniqueKeys[] = $candidate;
        }

        $actualCount = count($uniqueKeys);

        // Step 2: Build batch insert array for keys
        $keysBatch   = [];
        foreach ($uniqueKeys as $license) {
            $keysBatch[] = [
                'game'        => $game,
                'user_key'    => $license,
                'duration'    => $drtn,
                'max_devices' => $maxd,
                'registrator' => $user->username,
            ];
        }

        // Step 3: Insert all keys in one batch (atomic, no partial saves)
        if (!empty($keysBatch)) {
            $this->model->insertBatch($keysBatch);
        }

        // Step 4: Fetch inserted keys to get their IDs for history
        $insertedKeys = $this->model
            ->whereIn('user_key', $uniqueKeys)
            ->findAll();

        // Step 5: Build history batch and txt data
        $historyBatch = [];
        foreach ($insertedKeys as $row) {
            $generatedKeys[] = $row['user_key'] ?? $row->user_key;
            $key_val         = $row['user_key'] ?? $row->user_key;
            $key_id          = $row['id_keys']  ?? $row->id_keys;
            $txtData        .= "Key:- " . $key_val . "\n";

            $historyBatch[] = [
                'keys_id' => $key_id,
                'user_do' => $user->username,
                'info'    => "$game|" . substr($key_val, 0, 5) . "|$drtn|$maxd",
            ];
        }

        if (!empty($historyBatch)) {
            $history->insertBatch($historyBatch);
        }

        $actualCount = count($generatedKeys);

        // Save to new.txt for bulk download
        write_file('new.txt', $txtData);

        // Deduct total balance once
        $this->userModel->update(session('userid'), ['saldo' => $reduceCheck]);

        // Flash bulk keys for display
        session()->setFlashdata('bulk_keys',   $generatedKeys);
        session()->setFlashdata('game',        $game);
        session()->setFlashdata('duration',    $drtn);
        session()->setFlashdata('max_devices', $maxd);
        session()->setFlashdata('fees',        $totalPrice);

        $msg = $actualCount > 1
            ? "Successfully generated $actualCount keys!"
            : ($actualCount == 1 ? "Successfully generated 1 key!" : "Key generation failed. Please try again.");

        return redirect()->back()->with('msgSuccess', $msg);
    }
}
