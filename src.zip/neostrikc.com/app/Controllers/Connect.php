<?php

namespace App\Controllers;

use App\Models\KeysModel;
use CodeIgniter\I18n\Time;

class Connect extends BaseController {
    protected $model, $maintenance, $staticWords;

    public function __construct() {
        // Legacy connection for simple queries
        include('conn.php'); 
        $this->model = new KeysModel();
        
        $sql1 = "SELECT status FROM onoff WHERE id=1";
        $result1 = mysqli_query($conn, $sql1);
        $statusRow = mysqli_fetch_assoc($result1);
        
        $this->maintenance = (isset($statusRow['status']) && $statusRow['status'] == 'on');
        $this->staticWords = 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E';
    }

    public function index() {
        if ($this->request->getMethod() == 'post' || !empty(file_get_contents('php://input'))) {
            return $this->index_post();
        } else {
            return $this->response->setStatusCode(200)->setJSON([
                'message' => 'SERVER ONLINE',
                'author' => '@rohan_mods_papa'
            ]);
        }
    }

    public function XOR_encryption($value, $key) {
        $text = '';
        $klen = strlen($key);
        $vlen = strlen($value);
        if ($klen == 0) return $value; 
        for ($v = 0; $v < $vlen; $v++) {
            $text .= $value[$v] ^ $key[$v % $klen];
        }
        return $text;
    }

    public function get_Key($publicKey) {
        if (strlen($publicKey) < 80) return "1234567890"; 
        $keyDes = '';
        $indices = [58, 62, 10, 47, 20, 33, 87, 98, 14];
        foreach ($indices as $idx) {
            $keyDes .= $publicKey[$idx - 1];
        }
        return $keyDes;
    }

    public function readFileData($path) {
        return (file_exists($path) && !is_dir($path)) ? base64_encode(file_get_contents($path)) : "";
    }

    public function index_post() {
        $rawData = file_get_contents('php://input');
        $data_req = json_decode($rawData, true);
        
        $uKey = $data_req['key'] ?? null; 
        $publicKey = $data_req['publicKey'] ?? null;
        $uuid = $data_req['hwid'] ?? null;

        if ($this->maintenance) {
            include('conn.php');
            $res = mysqli_fetch_assoc(mysqli_query($conn, "SELECT myinput FROM onoff WHERE id=1"));
            return $this->response->setStatusCode(200)->setJSON([
                'status' => false, 
                'message' => $res['myinput'] ?? 'Maintenance Mode'
            ]);
        }

        // --- KEY FETCH ---
        $resKey = $this->model->where('user_key', $uKey)->first();
        if (!$resKey) {
            return $this->response->setStatusCode(200)->setJSON(['status' => false, 'message' => 'User Not Found']);
        }

        $findKey = (array) $resKey;
        $finalReseller = !empty($findKey['registrator']) ? strtoupper($findKey['registrator']) : "NEO STRIKE";

        // --- BAN CHECK ---
        if ($findKey['status'] != 1) {
            return $this->response->setStatusCode(200)->setJSON(['status' => false, 'message' => 'Key Banned']);
        }

        // --- EXPIRY LOGIC (FIXED) ---
        $time = new Time();
        $expired = $findKey['expired_date'];
        
        if (empty($expired)) {
            // Naya expiry set karo agar pehli baar login hai
            $expired = $time::now()->addDays((int)$findKey['duration'])->toDateTimeString();
            $this->model->update($findKey['id_keys'], ['expired_date' => $expired]);
        } else {
            // Agar expired date hai, toh check karo nikal toh nahi gayi
            if (!$time::parse($expired)->isAfter($time::now())) {
                return $this->response->setStatusCode(200)->setJSON(['status' => false, 'message' => 'Key Expired']);
            }
        }

        // --- HWID MANAGEMENT ---
        $lsDevice = !empty($findKey['devices']) ? explode(',', $findKey['devices']) : [];
        if (!in_array($uuid, $lsDevice)) {
            if (count($lsDevice) < $findKey['max_devices']) {
                $lsDevice[] = $uuid;
                $this->model->update($findKey['id_keys'], ['devices' => implode(',', $lsDevice)]);
            } else {
                return $this->response->setStatusCode(200)->setJSON(['status' => false, 'message' => 'Device Limit Reached']);
            }
        }

        // --- FETCH EXTRA FEATURES ---
        include('conn.php');
        $ftextRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT _status, _ftext FROM _ftext WHERE id=1"));
        $featRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM Feature WHERE id=1"));

        // --- PLAIN TEXT FOR JAVA PARSING ---
        // Yahan $expired ab update ho chuki hai, N/A nahi aayega
        $plainResponse = "SUCCESS|" . $finalReseller . "|" . $expired;

        return $this->response->setStatusCode(200)->setJSON([
            'status' => true,
            'plain_text' => $plainResponse, 
            'reseller' => $finalReseller,
            'mod_status' => $ftextRow['_status'] ?? 'Safe',
            'credit' => $ftextRow['_ftext'] ?? '@rohan_mods_papa',
            'ESP' => $featRow['ESP'] ?? 'off',
            'Item' => $featRow['Item'] ?? 'off',
            'AIM' => $featRow['AIM'] ?? 'off',
            'SilentAim' => $featRow['SilentAim'] ?? 'off',
            'BulletTrack' => $featRow['BulletTrack'] ?? 'off',
            'Floating' => $featRow['Floating'] ?? 'off',
            'Memory' => $featRow['Memory'] ?? 'off',
            'Setting' => $featRow['Setting'] ?? 'off',
            'expired_date' => $expired,
            'message' => "Login Success",
            'rng' => $time->getTimestamp(),
            'load' => ['load_data' => $this->readFileData("loader/libserver.so")],
            'auth' => [
                'message' => $this->XOR_encryption('Success', $this->get_Key($publicKey)),
                'token_access' => $publicKey,
            ],
        ]);
    }
}