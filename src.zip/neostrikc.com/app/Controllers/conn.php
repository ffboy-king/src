<?php

$servername = "sdb-78.hosting.stackcp.net";
$username = "neostrikccom-353037377050";
$password = "kpu9kwmosj";
$dbname = "neostrikccom-353037377050";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>