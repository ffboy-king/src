<?php
require_once __DIR__ . '/includes/config.php';

if (isLoggedIn()) redirect(SITE_URL . '/dashboard.php');

if (empty($_SESSION['cf_verified'])) {
    redirect(SITE_URL . '/security-check.php?r=/login.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Username aur password dono daalo.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare(
            "SELECT * FROM users WHERE (username = ? OR email = ?) AND is_active = 1 LIMIT 1"
        );
        $stmt->bind_param('ss', $username, $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            $db->query("UPDATE users SET last_login = NOW() WHERE id = {$user['id']}");
            redirect(SITE_URL . '/dashboard.php');
        } else {
            $error = 'Username ya password galat hai.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= SITE_NAME ?> — Login</title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Space Grotesk', sans-serif; }

    @keyframes panBg {
      0%   { background-position: 0% 50%; }
      50%  { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
    body {
      background: #080b14;
      min-height: 100vh;
      overflow-x: hidden;
    }

    /* Noise overlay */
    body::before {
      content: '';
      position: fixed; inset: 0; z-index: 0;
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.04'/%3E%3C/svg%3E");
      background-size: 200px 200px;
      pointer-events: none;
      opacity: .4;
    }

    /* Glowing lines */
    .line-h {
      position: fixed; left: 0; right: 0; height: 1px; z-index: 0; pointer-events: none;
      background: linear-gradient(90deg, transparent, rgba(99,102,241,.18), transparent);
    }
    .line-h.l1 { top: 30%; }
    .line-h.l2 { top: 68%; }
    .line-v {
      position: fixed; top: 0; bottom: 0; width: 1px; z-index: 0; pointer-events: none;
      background: linear-gradient(180deg, transparent, rgba(99,102,241,.12), transparent);
    }
    .line-v.v1 { left: 20%; }
    .line-v.v2 { right: 20%; }

    /* Orbs */
    @keyframes breathe {
      0%,100% { transform: scale(1) rotate(0deg); opacity: .6; }
      50%      { transform: scale(1.1) rotate(5deg); opacity: .9; }
    }
    .orb {
      position: fixed; border-radius: 50%;
      pointer-events: none; z-index: 0;
      animation: breathe 10s ease-in-out infinite;
    }
    .orb-a {
      width: 550px; height: 550px;
      background: radial-gradient(circle, rgba(99,102,241,.1), transparent 65%);
      top: -180px; left: -120px;
    }
    .orb-b {
      width: 450px; height: 450px;
      background: radial-gradient(circle, rgba(236,72,153,.07), transparent 65%);
      bottom: -150px; right: -100px;
      animation-duration: 13s; animation-direction: reverse;
    }

    /* Wrapper */
    .login-wrap {
      min-height: 100vh;
      display: flex; align-items: center; justify-content: center;
      padding: 32px 16px;
      position: relative; z-index: 1;
    }

    /* Card */
    .login-card {
      width: 100%; max-width: 420px;
      background: rgba(13, 16, 27, 0.9);
      border: 1px solid rgba(99,102,241,.22);
      border-radius: 22px;
      padding: 42px 34px 36px;
      backdrop-filter: blur(28px);
      box-shadow:
        0 0 0 1px rgba(99,102,241,.07),
        0 40px 90px rgba(0,0,0,.6),
        inset 0 1px 0 rgba(255,255,255,.05);
      position: relative;
      animation: popIn .5s cubic-bezier(.34,1.56,.64,1) both;
    }
    @keyframes popIn {
      from { opacity:0; transform:scale(.94) translateY(20px); }
      to   { opacity:1; transform:scale(1) translateY(0); }
    }

    /* Corner deco */
    .c { position:absolute; width:16px; height:16px; }
    .c.tl { top:12px; left:12px; border-top:1.5px solid rgba(99,102,241,.5); border-left:1.5px solid rgba(99,102,241,.5); border-radius:3px 0 0 0; }
    .c.tr { top:12px; right:12px; border-top:1.5px solid rgba(99,102,241,.5); border-right:1.5px solid rgba(99,102,241,.5); border-radius:0 3px 0 0; }
    .c.bl { bottom:12px; left:12px; border-bottom:1.5px solid rgba(236,72,153,.35); border-left:1.5px solid rgba(236,72,153,.35); border-radius:0 0 0 3px; }
    .c.br { bottom:12px; right:12px; border-bottom:1.5px solid rgba(236,72,153,.35); border-right:1.5px solid rgba(236,72,153,.35); border-radius:0 0 3px 0; }

    /* Header */
    .lh { text-align:center; margin-bottom:28px; }
    .lh-icon {
      width:60px; height:60px; margin:0 auto 14px;
      background: linear-gradient(135deg, rgba(99,102,241,.18), rgba(236,72,153,.12));
      border: 1px solid rgba(99,102,241,.3);
      border-radius:16px;
      display:flex; align-items:center; justify-content:center;
      font-size:1.6rem;
      box-shadow: 0 0 28px rgba(99,102,241,.2);
    }
    .lh h1 {
      font-size:1.35rem; font-weight:700; letter-spacing:.5px;
      background: linear-gradient(90deg, #a5b4fc, #f9a8d4);
      -webkit-background-clip:text; -webkit-text-fill-color:transparent;
      background-clip:text; margin-bottom:4px;
    }
    .lh p { font-size:.75rem; color:rgba(180,190,220,.38); letter-spacing:3px; text-transform:uppercase; }

    /* Divider */
    .ld { height:1px; background:linear-gradient(90deg,transparent,rgba(99,102,241,.2),transparent); margin-bottom:24px; }

    /* Error */
    .lerr {
      background:rgba(239,68,68,.09); border:1px solid rgba(239,68,68,.28);
      border-radius:9px; padding:10px 14px;
      font-size:.81rem; color:#fca5a5; margin-bottom:18px;
    }

    /* Fields */
    .lf { margin-bottom:16px; }
    .lf label {
      display:block; font-size:.74rem; font-weight:600;
      color:rgba(180,190,220,.55); letter-spacing:1.2px;
      text-transform:uppercase; margin-bottom:7px;
    }
    .lf input {
      width:100%;
      background:rgba(255,255,255,.035);
      border:1px solid rgba(99,102,241,.18);
      border-radius:10px; padding:12px 14px;
      color:#dde2f0; font-size:.9rem;
      font-family:'Space Grotesk',sans-serif;
      outline:none; transition:border-color .25s, box-shadow .25s;
    }
    .lf input:focus {
      border-color:rgba(99,102,241,.5);
      box-shadow:0 0 0 3px rgba(99,102,241,.09);
    }
    .lf input::placeholder { color:rgba(140,150,180,.35); }

    /* Button */
    .btn-login {
      width:100%; padding:14px;
      background:linear-gradient(135deg,#6366f1,#a855f7);
      color:#fff; font-family:'Space Grotesk',sans-serif;
      font-size:.87rem; font-weight:700; letter-spacing:2.5px;
      text-transform:uppercase; border:none; border-radius:12px;
      cursor:pointer; margin-top:4px;
      transition:all .3s; box-shadow:0 4px 22px rgba(99,102,241,.35);
    }
    .btn-login:hover { transform:translateY(-2px); box-shadow:0 8px 35px rgba(99,102,241,.5); }

    /* Links */
    .llinks { text-align:center; margin-top:20px; }
    .llinks a { font-size:.83rem; color:rgba(165,180,252,.7); text-decoration:none; transition:color .2s; }
    .llinks a:hover { color:#a5b4fc; }
    .llinks .sep { color:rgba(180,190,220,.2); margin:0 10px; }

    .lcopy { text-align:center; margin-top:28px; font-size:.65rem; letter-spacing:2px; text-transform:uppercase; color:rgba(180,190,220,.18); }
  </style>
</head>
<body>

<div class="orb orb-a"></div>
<div class="orb orb-b"></div>
<div class="line-h l1"></div>
<div class="line-h l2"></div>
<div class="line-v v1"></div>
<div class="line-v v2"></div>

<div class="login-wrap">
  <div class="login-card">
    <div class="c tl"></div><div class="c tr"></div>
    <div class="c bl"></div><div class="c br"></div>

    <div class="lh">
      <div class="lh-icon">⬡</div>
      <h1>FF PANEL STORE</h1>
      <p>Member Access Portal</p>
    </div>

    <div class="ld"></div>

    <?php if ($error): ?>
    <div class="lerr">⚠ &nbsp;<?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="lf">
        <label>Username or Email</label>
        <input type="text" name="username" placeholder="Username ya email daalo" required autocomplete="username">
      </div>
      <div class="lf">
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn-login">→ &nbsp;Sign In</button>
    </form>

    <div class="llinks">
      <a href="<?= SITE_URL ?>/forgot-password.php">Password bhul gaye?</a>
      <span class="sep">|</span>
      <a href="<?= SITE_URL ?>/register.php">Naya account banao</a>
    </div>

    <div class="lcopy">© <?= date('Y') ?> FF PANEL STORE</div>
  </div>
</div>

</body>
</html>
