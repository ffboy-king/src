<?php
// ============================================================
//  NEO STRIKE — Public HWID Reset Page
//  Place this file at: public_html/reset.php
// ============================================================

$servername = "sdb-78.hosting.stackcp.net";
$dbUsername = "neostrikccom-353037377050";
$dbPassword = "kpu9kwmosj";
$dbname     = "neostrikccom-353037377050";

$result  = null;
$status  = null; // 'success' | 'error' | 'warning'

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key  = trim($_POST['license_key'] ?? '');

    if (empty($key)) {
        $result = "Please enter your license key.";
        $status = "warning";
    } else {
        $conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbname);

        if (!$conn) {
            $result = "Server error. Please try again later.";
            $status = "error";
        } else {
            $safeKey    = mysqli_real_escape_string($conn, $key);
            $query      = mysqli_query($conn, "SELECT user_key, devices, daily_reset_count, last_reset_date, expired_date, status FROM keys_code WHERE user_key = '$safeKey'");

            if (mysqli_num_rows($query) > 0) {
                $row         = mysqli_fetch_assoc($query);
                $currentDate = date('Y-m-d');
                $resetCount  = intval($row['daily_reset_count']);
                $lastDate    = $row['last_reset_date'];
                $expDate     = $row['expired_date'];
                $keyStatus   = $row['status'];

                if (!$keyStatus) {
                    $result = "❌ This license key has been disabled. Contact your seller.";
                    $status = "error";
                } else {
                    // Reset count daily
                    if ($lastDate != $currentDate) {
                        $resetCount = 0;
                    }

                    if ($resetCount < 2) {
                        $newCount  = $resetCount + 1;
                        $remaining = 2 - $newCount;
                        $expShow   = $expDate ? date('d M Y', strtotime($expDate)) : "Lifetime";

                        $updateSql = "UPDATE keys_code SET 
                                      devices = NULL, 
                                      daily_reset_count = $newCount, 
                                      last_reset_date = '$currentDate',
                                      updated_at = NOW()
                                      WHERE user_key = '$safeKey'";

                        if (mysqli_query($conn, $updateSql)) {
                            $result  = "HWID reset successful! You can now login on your device.<br><small>Expiry: $expShow &nbsp;|&nbsp; Resets used today: $newCount/2 &nbsp;|&nbsp; Resets left: $remaining</small>";
                            $status  = "success";
                        } else {
                            $result = "System error. Please try again.";
                            $status = "error";
                        }
                    } else {
                        $nextReset = date('d M Y', strtotime('tomorrow'));
                        $result    = "Daily limit reached (2/2). Try again on <strong>$nextReset</strong>.";
                        $status    = "warning";
                    }
                }
            } else {
                $result = "Invalid license key. Please check and try again.";
                $status = "error";
            }

            mysqli_close($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NEO STRIKE — HWID Reset</title>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:        #050810;
    --panel:     #0b0f1a;
    --border:    #1a2340;
    --accent:    #00e5ff;
    --accent2:   #ff3c6e;
    --gold:      #ffd700;
    --text:      #c8d8f0;
    --muted:     #4a5a7a;
    --success:   #00ff88;
    --warning:   #ffb800;
    --error:     #ff3c6e;
    --glow:      0 0 20px rgba(0,229,255,0.25);
    --glow-red:  0 0 20px rgba(255,60,110,0.25);
  }

  * { margin: 0; padding: 0; box-sizing: border-box; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Rajdhani', sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
  }

  /* ── animated grid background ── */
  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(rgba(0,229,255,0.04) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,229,255,0.04) 1px, transparent 1px);
    background-size: 40px 40px;
    animation: gridMove 20s linear infinite;
    pointer-events: none;
  }

  @keyframes gridMove {
    0%   { background-position: 0 0; }
    100% { background-position: 40px 40px; }
  }

  /* ── glowing orbs ── */
  .orb {
    position: fixed;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.15;
    pointer-events: none;
    animation: orbFloat 8s ease-in-out infinite;
  }
  .orb1 { width: 400px; height: 400px; background: var(--accent);  top: -100px; left: -100px; animation-delay: 0s; }
  .orb2 { width: 300px; height: 300px; background: var(--accent2); bottom: -80px; right: -80px; animation-delay: 3s; }
  .orb3 { width: 200px; height: 200px; background: var(--gold);    top: 50%; left: 50%; animation-delay: 6s; }

  @keyframes orbFloat {
    0%, 100% { transform: translateY(0) scale(1); }
    50%       { transform: translateY(-30px) scale(1.1); }
  }

  /* ── main card ── */
  .card {
    position: relative;
    z-index: 10;
    width: 100%;
    max-width: 480px;
    margin: 20px;
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 4px;
    overflow: hidden;
    box-shadow: 0 0 60px rgba(0,0,0,0.8), var(--glow);
    animation: cardIn 0.6s cubic-bezier(0.16,1,0.3,1) both;
  }

  @keyframes cardIn {
    from { opacity: 0; transform: translateY(30px) scale(0.97); }
    to   { opacity: 1; transform: translateY(0) scale(1); }
  }

  /* ── top stripe ── */
  .stripe {
    height: 3px;
    background: linear-gradient(90deg, var(--accent2), var(--accent), var(--gold));
    background-size: 200% 100%;
    animation: stripeShift 3s linear infinite;
  }

  @keyframes stripeShift {
    0%   { background-position: 0% 0%; }
    100% { background-position: 200% 0%; }
  }

  /* ── header ── */
  .header {
    padding: 32px 36px 24px;
    border-bottom: 1px solid var(--border);
    position: relative;
  }

  .logo-row {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-bottom: 6px;
  }

  .logo-icon {
    width: 44px;
    height: 44px;
    background: linear-gradient(135deg, var(--accent2), var(--accent));
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    box-shadow: var(--glow);
    flex-shrink: 0;
  }

  .brand {
    font-size: 24px;
    font-weight: 700;
    letter-spacing: 3px;
    text-transform: uppercase;
    background: linear-gradient(90deg, #fff, var(--accent));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .tagline {
    font-size: 13px;
    color: var(--muted);
    letter-spacing: 2px;
    text-transform: uppercase;
    font-family: 'Share Tech Mono', monospace;
    margin-top: 2px;
  }

  .badge {
    position: absolute;
    top: 28px;
    right: 36px;
    background: rgba(0,255,136,0.1);
    border: 1px solid rgba(0,255,136,0.3);
    color: var(--success);
    font-size: 11px;
    font-family: 'Share Tech Mono', monospace;
    padding: 4px 10px;
    border-radius: 2px;
    letter-spacing: 1px;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .badge::before {
    content: '';
    width: 6px;
    height: 6px;
    background: var(--success);
    border-radius: 50%;
    box-shadow: 0 0 6px var(--success);
    animation: blink 1.5s ease-in-out infinite;
  }

  @keyframes blink {
    0%, 100% { opacity: 1; }
    50%       { opacity: 0.3; }
  }

  /* ── body ── */
  .body {
    padding: 32px 36px 36px;
  }

  .section-title {
    font-size: 11px;
    font-family: 'Share Tech Mono', monospace;
    color: var(--muted);
    letter-spacing: 3px;
    text-transform: uppercase;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .section-title::after {
    content: '';
    flex: 1;
    height: 1px;
    background: var(--border);
  }

  /* ── input group ── */
  .input-group {
    position: relative;
    margin-bottom: 20px;
  }

  .input-label {
    display: block;
    font-size: 12px;
    font-family: 'Share Tech Mono', monospace;
    color: var(--muted);
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-bottom: 10px;
  }

  .input-wrap {
    position: relative;
  }

  .input-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 16px;
    color: var(--muted);
    pointer-events: none;
    transition: color 0.2s;
  }

  input[type="text"] {
    width: 100%;
    background: rgba(255,255,255,0.03);
    border: 1px solid var(--border);
    border-radius: 3px;
    padding: 14px 14px 14px 44px;
    color: #fff;
    font-family: 'Share Tech Mono', monospace;
    font-size: 15px;
    letter-spacing: 2px;
    text-transform: uppercase;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
  }

  input[type="text"]::placeholder {
    color: var(--muted);
    letter-spacing: 1px;
    text-transform: none;
    font-size: 13px;
  }

  input[type="text"]:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(0,229,255,0.08), var(--glow);
    background: rgba(0,229,255,0.03);
  }

  input[type="text"]:focus + .input-icon,
  .input-wrap:focus-within .input-icon {
    color: var(--accent);
  }

  /* ── rules box ── */
  .rules {
    background: rgba(255,184,0,0.05);
    border: 1px solid rgba(255,184,0,0.15);
    border-radius: 3px;
    padding: 14px 16px;
    margin-bottom: 24px;
    font-size: 13px;
    color: #a0a8b8;
    line-height: 1.7;
  }

  .rules span {
    color: var(--gold);
    font-weight: 600;
  }

  /* ── submit button ── */
  .btn {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, #ff3c6e, #00e5ff);
    border: none;
    border-radius: 3px;
    color: #fff;
    font-family: 'Rajdhani', sans-serif;
    font-size: 16px;
    font-weight: 700;
    letter-spacing: 4px;
    text-transform: uppercase;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: opacity 0.2s, transform 0.1s;
  }

  .btn::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.15), transparent);
    opacity: 0;
    transition: opacity 0.2s;
  }

  .btn:hover::before { opacity: 1; }
  .btn:hover { opacity: 0.92; }
  .btn:active { transform: scale(0.99); }

  .btn.loading {
    pointer-events: none;
    opacity: 0.7;
  }

  .btn-text { position: relative; z-index: 1; }

  /* ── result alert ── */
  .alert {
    margin-bottom: 24px;
    padding: 16px 18px;
    border-radius: 3px;
    font-size: 14px;
    line-height: 1.6;
    font-weight: 500;
    display: flex;
    gap: 12px;
    align-items: flex-start;
    animation: alertIn 0.4s cubic-bezier(0.16,1,0.3,1) both;
  }

  @keyframes alertIn {
    from { opacity: 0; transform: translateY(-8px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  .alert-icon { font-size: 18px; flex-shrink: 0; margin-top: 1px; }

  .alert.success {
    background: rgba(0,255,136,0.07);
    border: 1px solid rgba(0,255,136,0.25);
    color: #80ffbc;
  }

  .alert.error {
    background: rgba(255,60,110,0.07);
    border: 1px solid rgba(255,60,110,0.25);
    color: #ff8aaa;
  }

  .alert.warning {
    background: rgba(255,184,0,0.07);
    border: 1px solid rgba(255,184,0,0.25);
    color: #ffd066;
  }

  /* ── footer ── */
  .footer {
    padding: 18px 36px;
    border-top: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 11px;
    font-family: 'Share Tech Mono', monospace;
    color: var(--muted);
    letter-spacing: 1px;
  }

  .footer-limit {
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .dot { width: 5px; height: 5px; border-radius: 50%; background: var(--accent); }

  /* ── scanline overlay ── */
  body::after {
    content: '';
    position: fixed;
    inset: 0;
    background: repeating-linear-gradient(
      0deg,
      transparent,
      transparent 2px,
      rgba(0,0,0,0.03) 2px,
      rgba(0,0,0,0.03) 4px
    );
    pointer-events: none;
    z-index: 9999;
  }

  /* ── corner decorations ── */
  .corner {
    position: absolute;
    width: 12px;
    height: 12px;
    border-color: var(--accent);
    border-style: solid;
    opacity: 0.5;
  }
  .corner-tl { top: 8px; left: 8px; border-width: 1px 0 0 1px; }
  .corner-tr { top: 8px; right: 8px; border-width: 1px 1px 0 0; }
  .corner-bl { bottom: 8px; left: 8px; border-width: 0 0 1px 1px; }
  .corner-br { bottom: 8px; right: 8px; border-width: 0 1px 1px 0; }

  @media (max-width: 520px) {
    .header, .body { padding-left: 24px; padding-right: 24px; }
    .footer { padding-left: 24px; padding-right: 24px; }
    .badge { display: none; }
  }
</style>
</head>
<body>

<div class="orb orb1"></div>
<div class="orb orb2"></div>
<div class="orb orb3"></div>

<div class="card">
  <div class="corner corner-tl"></div>
  <div class="corner corner-tr"></div>
  <div class="corner corner-bl"></div>
  <div class="corner corner-br"></div>

  <div class="stripe"></div>

  <div class="header">
    <div class="logo-row">
      <div class="logo-icon">⚡</div>
      <div>
        <div class="brand">Neo Strike</div>
        <div class="tagline">HWID Reset Portal</div>
      </div>
    </div>
    <div class="badge">ONLINE</div>
  </div>

  <div class="body">
    <div class="section-title">Device Reset</div>

    <?php if ($result): ?>
    <div class="alert <?= htmlspecialchars($status) ?>">
      <span class="alert-icon">
        <?php
          if ($status === 'success') echo '✅';
          elseif ($status === 'error') echo '❌';
          else echo '⚠️';
        ?>
      </span>
      <div><?= $result ?></div>
    </div>
    <?php endif; ?>

    <form method="POST" id="resetForm">
      <div class="input-group">
        <label class="input-label" for="license_key">License Key</label>
        <div class="input-wrap">
          <input
            type="text"
            id="license_key"
            name="license_key"
            placeholder="Enter your license key"
            value="<?= htmlspecialchars($_POST['license_key'] ?? '') ?>"
            autocomplete="off"
            autocorrect="off"
            spellcheck="false"
            maxlength="50"
          >
          <span class="input-icon">🔑</span>
        </div>
      </div>

      <div class="rules">
        <span>⚠ Rules:</span> Max <span>2 resets/day</span> per key &nbsp;•&nbsp;
        Key must be <span>active & valid</span> &nbsp;•&nbsp;
        Do not share your key
      </div>

      <button type="submit" class="btn" id="submitBtn">
        <span class="btn-text">Reset HWID</span>
      </button>
    </form>
  </div>

  <div class="footer">
    <div class="footer-limit">
      <div class="dot"></div>
      <span>2 resets per day</span>
    </div>
    <span>NEO STRIKE © <?= date('Y') ?></span>
  </div>
</div>

<script>
  document.getElementById('resetForm').addEventListener('submit', function() {
    const btn = document.getElementById('submitBtn');
    btn.classList.add('loading');
    btn.querySelector('.btn-text').textContent = 'Processing...';
  });

  // Auto uppercase input
  document.getElementById('license_key').addEventListener('input', function() {
    const pos = this.selectionStart;
    this.value = this.value.toUpperCase();
    this.setSelectionRange(pos, pos);
  });
</script>

</body>
</html>
