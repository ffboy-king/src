<?php
$servername = "sdb-78.hosting.stackcp.net";
$dbUsername = "neostrikccom-353037377050";
$dbPassword = "kpu9kwmosj";
$dbname     = "neostrikccom-353037377050";

$conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbname);

if (!$conn) {
    echo "DB Error: " . mysqli_connect_error();
} else {
    echo "Database Connected Successfully!";
}
?>