<?php
// ============================================================
//   TELEGRAM MINI APP — Shop Bot
//   Pages: Shop, My Orders, Profile, Admin Dashboard
// ============================================================

define('BOT_TOKEN', '8672791705:AAEOQ-yV2ULvK_cN5P1-uwz2I4znhzTz4LU');
define('OWNER_ID',  '6680567083');
define('DB_FILE',   __DIR__ . '/shop_data.json');

// ─── Validate Telegram InitData ───────────────────────────────
function validateTelegramData($initData) {
    parse_str($initData, $params);
    $hash = isset($params['hash']) ? $params['hash'] : '';
    unset($params['hash']);
    ksort($params);
    $dataCheckString = implode("\n", array_map(fn($k,$v) => "$k=$v", array_keys($params), $params));
    $secretKey = hash_hmac('sha256', BOT_TOKEN, 'WebAppData', true);
    $expectedHash = hash_hmac('sha256', $dataCheckString, $secretKey);
    return hash_equals($expectedHash, $hash) ? $params : false;
}

// ─── Load DB ──────────────────────────────────────────────────
function loadDB() {
    if (!file_exists(DB_FILE)) return ['products'=>[],'users'=>[],'orders'=>[],'pending'=>[],'broadcasts'=>[]];
    $d = json_decode(file_get_contents(DB_FILE), true);
    return $d ?: ['products'=>[],'users'=>[],'orders'=>[],'pending'=>[],'broadcasts'=>[]];
}

function saveDB($data) {
    file_put_contents(DB_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// ─── API Handler (JSON) ───────────────────────────────────────
if (isset($_GET['api'])) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');

    $initData = isset($_POST['initData']) ? $_POST['initData'] : (isset($_GET['initData']) ? $_GET['initData'] : '');
    $action   = isset($_GET['action']) ? $_GET['action'] : '';

    // Dev mode: skip validation if initData is 'dev'
    $user_id = null;
    if ($initData === 'dev') {
        $user_id = OWNER_ID;
    } else {
        $validated = validateTelegramData($initData);
        if ($validated && isset($validated['user'])) {
            $userData = json_decode($validated['user'], true);
            $user_id  = $userData['id'] ?? null;
        }
    }

    if (!$user_id) { echo json_encode(['ok'=>false,'error'=>'Unauthorized']); exit; }

    $db      = loadDB();
    $is_owner = (string)$user_id === (string)OWNER_ID;

    switch ($action) {

        case 'get_home':
            $user   = $db['users'][$user_id] ?? null;
            $orders = [];
            if ($user && isset($user['orders'])) {
                foreach (array_slice(array_reverse($user['orders']), 0, 3) as $oid) {
                    if (isset($db['orders'][$oid])) $orders[] = $db['orders'][$oid];
                }
            }
            $products = array_values($db['products']);
            echo json_encode(['ok'=>true,'user'=>$user,'recent_orders'=>$orders,'products'=>$products,'is_owner'=>$is_owner]);
            break;

        case 'get_products':
            echo json_encode(['ok'=>true,'products'=>array_values($db['products'])]);
            break;

        case 'get_orders':
            $user   = $db['users'][$user_id] ?? null;
            $orders = [];
            if ($user && isset($user['orders'])) {
                foreach (array_reverse($user['orders']) as $oid) {
                    if (isset($db['orders'][$oid])) $orders[] = $db['orders'][$oid];
                }
            }
            echo json_encode(['ok'=>true,'orders'=>$orders]);
            break;

        case 'get_profile':
            $user = $db['users'][$user_id] ?? null;
            $order_count = $user ? count($user['orders'] ?? []) : 0;
            $total_spent = 0;
            if ($user) {
                foreach ($user['orders'] ?? [] as $oid) {
                    if (isset($db['orders'][$oid])) $total_spent += $db['orders'][$oid]['price'];
                }
            }
            echo json_encode(['ok'=>true,'user'=>$user,'order_count'=>$order_count,'total_spent'=>$total_spent,'is_owner'=>$is_owner]);
            break;

        // ── ADMIN ──
        case 'get_stats':
            if (!$is_owner) { echo json_encode(['ok'=>false,'error'=>'Forbidden']); exit; }
            $revenue = 0;
            foreach ($db['orders'] as $o) $revenue += $o['price'];
            $total_keys = 0;
            foreach ($db['products'] as $p) {
                if (isset($p['plans'])) foreach ($p['keys'] as $ks) $total_keys += count($ks);
                else $total_keys += count($p['keys'] ?? []);
            }
            echo json_encode([
                'ok'       => true,
                'users'    => count($db['users']),
                'products' => count($db['products']),
                'orders'   => count($db['orders']),
                'pending'  => count($db['pending']),
                'revenue'  => $revenue,
                'keys'     => $total_keys,
            ]);
            break;

        case 'get_pending':
            if (!$is_owner) { echo json_encode(['ok'=>false,'error'=>'Forbidden']); exit; }
            $list = [];
            foreach ($db['pending'] as $key => $p) {
                $prod = $db['products'][$p['product_id']] ?? ['name'=>'Unknown'];
                $buyer = $db['users'][$p['user_id']] ?? ['name'=>'Unknown','username'=>''];
                $plan_i = (int)$p['plan_i'];
                $plan_label = $plan_i === -1 ? $prod['name'] : ($prod['plans'][$plan_i]['days']??'?').' Day';
                $price = $plan_i === -1 ? ($prod['price']??0) : ($prod['plans'][$plan_i]['price']??0);
                $list[] = [
                    'key'        => $key,
                    'buyer_name' => $buyer['name'],
                    'buyer_user' => $buyer['username'] ?? '',
                    'product'    => $prod['name'],
                    'plan'       => $plan_label,
                    'price'      => $price,
                    'utr'        => $p['utr'],
                    'pay_name'   => $p['pay_name'],
                    'date'       => $p['date'],
                ];
            }
            echo json_encode(['ok'=>true,'pending'=>$list]);
            break;

        case 'get_all_orders':
            if (!$is_owner) { echo json_encode(['ok'=>false,'error'=>'Forbidden']); exit; }
            $orders = array_values(array_reverse($db['orders']));
            echo json_encode(['ok'=>true,'orders'=>$orders]);
            break;

        case 'get_all_users':
            if (!$is_owner) { echo json_encode(['ok'=>false,'error'=>'Forbidden']); exit; }
            $users = [];
            foreach ($db['users'] as $u) {
                $users[] = [
                    'id'       => $u['id'],
                    'name'     => $u['name'],
                    'username' => $u['username'] ?? '',
                    'phone'    => $u['phone'] ?? '',
                    'verified' => $u['phone_verified'] ?? false,
                    'orders'   => count($u['orders'] ?? []),
                    'joined'   => $u['joined'],
                    'points'   => $u['ref_points'] ?? 0,
                ];
            }
            echo json_encode(['ok'=>true,'users'=>$users]);
            break;

        default:
            echo json_encode(['ok'=>false,'error'=>'Unknown action']);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Shop Bot</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<style>
:root {
  --bg:       #0a0a0f;
  --surface:  #13131a;
  --card:     #1a1a24;
  --border:   #2a2a38;
  --accent:   #7c6ef9;
  --accent2:  #f97c6e;
  --green:    #6ef9a0;
  --yellow:   #f9e46e;
  --text:     #eeeef5;
  --muted:    #7070a0;
  --radius:   16px;
  --font:     'Sora', sans-serif;
  --mono:     'JetBrains Mono', monospace;
}

* { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }

body {
  font-family: var(--font);
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  overflow-x: hidden;
}

/* ── LOADER ── */
#loader {
  position: fixed; inset: 0; background: var(--bg);
  display: flex; align-items: center; justify-content: center;
  z-index: 999; flex-direction: column; gap: 16px;
}
.loader-ring {
  width: 48px; height: 48px; border-radius: 50%;
  border: 3px solid var(--border);
  border-top-color: var(--accent);
  animation: spin 0.8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.loader-text { color: var(--muted); font-size: 13px; letter-spacing: 2px; text-transform: uppercase; }

/* ── LAYOUT ── */
.app { display: flex; flex-direction: column; height: 100vh; }

/* ── HEADER ── */
.header {
  padding: 16px 20px 12px;
  display: flex; align-items: center; justify-content: space-between;
  border-bottom: 1px solid var(--border);
  background: var(--bg);
  position: sticky; top: 0; z-index: 10;
}
.header-logo {
  font-size: 18px; font-weight: 700; letter-spacing: -0.5px;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.header-badge {
  background: var(--accent); color: white;
  font-size: 10px; font-weight: 600; padding: 3px 8px;
  border-radius: 20px; letter-spacing: 1px;
}

/* ── CONTENT ── */
.content {
  flex: 1; overflow-y: auto; padding: 20px;
  padding-bottom: 90px;
}
.content::-webkit-scrollbar { display: none; }

/* ── PAGES ── */
.page { display: none; animation: fadeUp 0.3s ease; }
.page.active { display: block; }
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* ── NAV BAR ── */
.navbar {
  position: fixed; bottom: 0; left: 0; right: 0;
  background: var(--surface);
  border-top: 1px solid var(--border);
  display: flex; padding: 8px 0 20px;
  z-index: 10;
}
.nav-item {
  flex: 1; display: flex; flex-direction: column;
  align-items: center; gap: 4px;
  padding: 6px; cursor: pointer;
  color: var(--muted); font-size: 10px; font-weight: 500;
  transition: color 0.2s;
  border: none; background: none;
}
.nav-item.active { color: var(--accent); }
.nav-item svg { width: 22px; height: 22px; transition: transform 0.2s; }
.nav-item.active svg { transform: scale(1.15); }
.nav-badge {
  position: absolute; top: -2px; right: -2px;
  background: var(--accent2); color: white;
  font-size: 9px; font-weight: 700;
  width: 16px; height: 16px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
.nav-icon-wrap { position: relative; }

/* ── CARDS ── */
.card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 16px; margin-bottom: 12px;
  transition: border-color 0.2s, transform 0.15s;
}
.card:active { transform: scale(0.985); }

/* ── SECTION TITLE ── */
.section-title {
  font-size: 11px; font-weight: 600; color: var(--muted);
  letter-spacing: 2px; text-transform: uppercase;
  margin-bottom: 12px; margin-top: 8px;
}

/* ── HOME PAGE ── */
.hero {
  background: linear-gradient(135deg, #1a1428 0%, #141428 100%);
  border: 1px solid var(--border);
  border-radius: var(--radius); padding: 20px; margin-bottom: 20px;
  position: relative; overflow: hidden;
}
.hero::before {
  content: ''; position: absolute; inset: 0;
  background: radial-gradient(ellipse at 80% 20%, rgba(124,110,249,0.15) 0%, transparent 60%);
}
.hero-greeting { font-size: 13px; color: var(--muted); margin-bottom: 4px; }
.hero-name { font-size: 22px; font-weight: 700; margin-bottom: 12px; }
.hero-stats { display: flex; gap: 16px; }
.hero-stat-val { font-size: 18px; font-weight: 700; color: var(--accent); font-family: var(--mono); }
.hero-stat-lbl { font-size: 11px; color: var(--muted); margin-top: 1px; }

.quick-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; }
.quick-btn {
  background: var(--card); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 14px;
  display: flex; flex-direction: column; align-items: flex-start; gap: 8px;
  cursor: pointer; transition: all 0.2s; text-align: left;
}
.quick-btn:active { transform: scale(0.96); border-color: var(--accent); }
.quick-btn-icon { font-size: 22px; }
.quick-btn-label { font-size: 13px; font-weight: 600; }
.quick-btn-sub { font-size: 11px; color: var(--muted); }

/* ── PRODUCT CARD ── */
.product-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 16px; margin-bottom: 12px;
  transition: border-color 0.2s;
}
.product-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
.product-name { font-size: 15px; font-weight: 600; }
.product-desc { font-size: 12px; color: var(--muted); margin-bottom: 12px; line-height: 1.5; }
.plans-grid { display: flex; flex-direction: column; gap: 6px; }
.plan-row {
  display: flex; justify-content: space-between; align-items: center;
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 10px; padding: 10px 14px;
}
.plan-days { font-size: 13px; font-weight: 600; }
.plan-price { font-size: 14px; font-weight: 700; color: var(--accent); font-family: var(--mono); }
.plan-stock { font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 20px; }
.in-stock { background: rgba(110,249,160,0.15); color: var(--green); }
.out-stock { background: rgba(249,124,110,0.15); color: var(--accent2); }

/* ── ORDER CARD ── */
.order-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 16px; margin-bottom: 10px;
}
.order-header { display: flex; justify-content: space-between; margin-bottom: 10px; }
.order-id { font-size: 11px; font-family: var(--mono); color: var(--accent); font-weight: 600; }
.order-date { font-size: 11px; color: var(--muted); }
.order-product { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
.order-plan { font-size: 12px; color: var(--muted); margin-bottom: 10px; }
.key-box {
  background: var(--surface); border: 1px dashed var(--border);
  border-radius: 10px; padding: 10px 12px;
  font-family: var(--mono); font-size: 12px; color: var(--green);
  word-break: break-all; cursor: pointer;
  transition: border-color 0.2s;
  position: relative;
}
.key-box:active { border-color: var(--green); }
.key-copy-hint { font-size: 10px; color: var(--muted); margin-top: 4px; text-align: right; }
.order-price { font-size: 16px; font-weight: 700; font-family: var(--mono); color: var(--yellow); }

/* ── PROFILE ── */
.profile-avatar {
  width: 72px; height: 72px; border-radius: 50%;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  display: flex; align-items: center; justify-content: center;
  font-size: 28px; font-weight: 700; margin: 0 auto 16px;
}
.profile-name { text-align: center; font-size: 20px; font-weight: 700; margin-bottom: 4px; }
.profile-handle { text-align: center; font-size: 13px; color: var(--muted); margin-bottom: 20px; }
.profile-stats { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 20px; }
.stat-box {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 12px; padding: 14px 8px; text-align: center;
}
.stat-val { font-size: 18px; font-weight: 700; font-family: var(--mono); color: var(--accent); }
.stat-lbl { font-size: 10px; color: var(--muted); margin-top: 2px; text-transform: uppercase; letter-spacing: 1px; }
.info-row {
  display: flex; justify-content: space-between; align-items: center;
  padding: 12px 0; border-bottom: 1px solid var(--border);
}
.info-row:last-child { border-bottom: none; }
.info-lbl { font-size: 12px; color: var(--muted); }
.info-val { font-size: 13px; font-weight: 500; }
.badge-verified { background: rgba(110,249,160,0.15); color: var(--green); font-size: 11px; padding: 3px 10px; border-radius: 20px; }
.badge-unverified { background: rgba(249,124,110,0.15); color: var(--accent2); font-size: 11px; padding: 3px 10px; border-radius: 20px; }

/* ── ADMIN ── */
.stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; }
.stat-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 16px;
}
.stat-card-val { font-size: 24px; font-weight: 700; font-family: var(--mono); margin-bottom: 4px; }
.stat-card-lbl { font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; }
.stat-card.revenue .stat-card-val { color: var(--green); }
.stat-card.users .stat-card-val { color: var(--accent); }
.stat-card.orders .stat-card-val { color: var(--yellow); }
.stat-card.pending .stat-card-val { color: var(--accent2); }
.stat-card.products .stat-card-val { color: #a0f9f9; }
.stat-card.keys .stat-card-val { color: #f9a0f9; }

.admin-tabs { display: flex; gap: 6px; margin-bottom: 16px; overflow-x: auto; padding-bottom: 2px; }
.admin-tab {
  padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600;
  background: var(--surface); border: 1px solid var(--border);
  color: var(--muted); cursor: pointer; white-space: nowrap;
  transition: all 0.2s;
}
.admin-tab.active { background: var(--accent); border-color: var(--accent); color: white; }

.pending-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 14px; margin-bottom: 10px;
}
.pending-header { display: flex; justify-content: space-between; margin-bottom: 8px; }
.pending-user { font-size: 13px; font-weight: 600; }
.pending-date { font-size: 11px; color: var(--muted); }
.pending-product { font-size: 12px; color: var(--muted); margin-bottom: 6px; }
.pending-utr { font-family: var(--mono); font-size: 12px; color: var(--yellow); margin-bottom: 10px; }
.pending-price { font-size: 15px; font-weight: 700; color: var(--accent); font-family: var(--mono); margin-bottom: 12px; }
.pending-actions { display: flex; gap: 8px; }

.user-row {
  display: flex; align-items: center; gap: 12px;
  padding: 12px 0; border-bottom: 1px solid var(--border);
}
.user-avatar {
  width: 40px; height: 40px; border-radius: 50%;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  display: flex; align-items: center; justify-content: center;
  font-size: 16px; font-weight: 700; flex-shrink: 0;
}
.user-info { flex: 1; min-width: 0; }
.user-name { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.user-meta { font-size: 11px; color: var(--muted); margin-top: 2px; }
.user-orders { font-size: 12px; font-weight: 600; color: var(--accent); font-family: var(--mono); }

/* ── BUTTONS ── */
.btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  padding: 12px 20px; border-radius: 12px;
  font-family: var(--font); font-size: 13px; font-weight: 600;
  border: none; cursor: pointer; transition: all 0.2s;
  width: 100%;
}
.btn:active { transform: scale(0.97); }
.btn-primary { background: var(--accent); color: white; }
.btn-primary:hover { background: #8f80ff; }
.btn-success { background: rgba(110,249,160,0.15); color: var(--green); border: 1px solid var(--green); }
.btn-danger  { background: rgba(249,124,110,0.15); color: var(--accent2); border: 1px solid var(--accent2); }
.btn-sm { padding: 7px 14px; font-size: 12px; border-radius: 8px; }

/* ── EMPTY STATE ── */
.empty-state {
  text-align: center; padding: 48px 20px;
  color: var(--muted);
}
.empty-icon { font-size: 48px; margin-bottom: 12px; }
.empty-text { font-size: 14px; font-weight: 500; }
.empty-sub { font-size: 12px; margin-top: 6px; opacity: 0.6; }

/* ── TOAST ── */
#toast {
  position: fixed; bottom: 90px; left: 50%; transform: translateX(-50%) translateY(20px);
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 20px; padding: 10px 20px;
  font-size: 13px; font-weight: 500; color: var(--text);
  opacity: 0; transition: all 0.3s; pointer-events: none;
  white-space: nowrap; z-index: 999;
}
#toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }

/* ── SCROLLBAR ── */
::-webkit-scrollbar { width: 4px; height: 4px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

/* ── SHIMMER ── */
.shimmer {
  background: linear-gradient(90deg, var(--card) 25%, var(--border) 50%, var(--card) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.2s infinite;
  border-radius: 8px;
}
@keyframes shimmer { to { background-position: -200% 0; } }
.shimmer-line { height: 14px; margin-bottom: 8px; }
</style>
</head>
<body>

<!-- Loader -->
<div id="loader">
  <div class="loader-ring"></div>
  <div class="loader-text">Loading...</div>
</div>

<!-- App -->
<div class="app" id="app" style="display:none">

  <!-- Header -->
  <div class="header">
    <div class="header-logo">🛒 ShopBot</div>
    <div id="header-right"></div>
  </div>

  <!-- Content -->
  <div class="content">

    <!-- HOME -->
    <div class="page active" id="page-home">
      <div id="home-content">
        <div style="height:180px" class="shimmer" style="border-radius:16px;margin-bottom:20px"></div>
      </div>
    </div>

    <!-- SHOP -->
    <div class="page" id="page-shop">
      <div class="section-title">Available Products</div>
      <div id="shop-content">
        <div class="shimmer shimmer-line" style="height:100px;margin-bottom:12px"></div>
        <div class="shimmer shimmer-line" style="height:100px"></div>
      </div>
    </div>

    <!-- ORDERS -->
    <div class="page" id="page-orders">
      <div class="section-title">Purchase History</div>
      <div id="orders-content">
        <div class="shimmer shimmer-line" style="height:120px;margin-bottom:10px"></div>
      </div>
    </div>

    <!-- PROFILE -->
    <div class="page" id="page-profile">
      <div id="profile-content">
        <div class="shimmer shimmer-line" style="height:200px"></div>
      </div>
    </div>

    <!-- ADMIN -->
    <div class="page" id="page-admin">
      <div class="section-title">Admin Panel</div>
      <div id="admin-content"></div>
    </div>

  </div>

  <!-- Navbar -->
  <nav class="navbar">
    <button class="nav-item active" onclick="navTo('home')" id="nav-home">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      Home
    </button>
    <button class="nav-item" onclick="navTo('shop')" id="nav-shop">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 001.96-1.59L23 6H6"/></svg>
      Shop
    </button>
    <button class="nav-item" onclick="navTo('orders')" id="nav-orders">
      <div class="nav-icon-wrap">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
      </div>
      Orders
    </button>
    <button class="nav-item" onclick="navTo('profile')" id="nav-profile">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      Profile
    </button>
    <button class="nav-item" onclick="navTo('admin')" id="nav-admin" style="display:none">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      Admin
    </button>
  </nav>
</div>

<!-- Toast -->
<div id="toast"></div>

<script>
const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
  tg.setHeaderColor('#0a0a0f');
  tg.setBackgroundColor('#0a0a0f');
}

const BASE = window.location.href.split('?')[0] + '?api=1';
const initData = tg?.initData || 'dev';
let currentPage = 'home';
let isOwner = false;
let userData = null;

async function api(action, extra = {}) {
  const body = new FormData();
  body.append('initData', initData);
  const res = await fetch(`${BASE}&action=${action}`, { method: 'POST', body });
  return res.json();
}

function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2000);
}

function navTo(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.getElementById('nav-' + page).classList.add('active');
  currentPage = page;
  loadPage(page);
}

async function loadPage(page) {
  if (page === 'home')    loadHome();
  if (page === 'shop')    loadShop();
  if (page === 'orders')  loadOrders();
  if (page === 'profile') loadProfile();
  if (page === 'admin')   loadAdmin();
}

// ── HOME ──────────────────────────────────────────────────────
async function loadHome() {
  const data = await api('get_home');
  if (!data.ok) return;
  isOwner = data.is_owner;
  userData = data.user;

  if (isOwner) {
    document.getElementById('nav-admin').style.display = '';
    document.getElementById('header-right').innerHTML = '<div class="header-badge">ADMIN</div>';
  }

  const orders = data.recent_orders || [];
  const prods  = data.products || [];
  const name   = data.user?.name || 'User';
  const orderCount = data.user?.orders?.length || 0;
  let totalKeys = 0;
  prods.forEach(p => {
    if (p.plans) p.keys?.forEach(k => totalKeys += k.length);
    else totalKeys += (p.keys?.length || 0);
  });

  document.getElementById('home-content').innerHTML = `
    <div class="hero">
      <div class="hero-greeting">Welcome back 👋</div>
      <div class="hero-name">${name}</div>
      <div class="hero-stats">
        <div>
          <div class="hero-stat-val">${orderCount}</div>
          <div class="hero-stat-lbl">My Orders</div>
        </div>
        <div>
          <div class="hero-stat-val">${prods.length}</div>
          <div class="hero-stat-lbl">Products</div>
        </div>
      </div>
    </div>

    <div class="quick-actions">
      <div class="quick-btn" onclick="navTo('shop')">
        <div class="quick-btn-icon">🛍️</div>
        <div class="quick-btn-label">Shop Now</div>
        <div class="quick-btn-sub">${prods.length} products</div>
      </div>
      <div class="quick-btn" onclick="navTo('orders')">
        <div class="quick-btn-icon">📦</div>
        <div class="quick-btn-label">My Orders</div>
        <div class="quick-btn-sub">${orderCount} total</div>
      </div>
    </div>

    ${orders.length > 0 ? `
    <div class="section-title">Recent Orders</div>
    ${orders.map(o => orderCardHTML(o)).join('')}
    ` : ''}

    <div class="section-title">Featured Products</div>
    ${prods.slice(0,2).map(p => productCardHTML(p)).join('')}
  `;
}

// ── SHOP ──────────────────────────────────────────────────────
async function loadShop() {
  const data = await api('get_products');
  if (!data.ok) return;
  const prods = data.products || [];
  if (!prods.length) {
    document.getElementById('shop-content').innerHTML = `
      <div class="empty-state"><div class="empty-icon">🏪</div><div class="empty-text">No Products Yet</div><div class="empty-sub">Check back soon!</div></div>`;
    return;
  }
  document.getElementById('shop-content').innerHTML = prods.map(p => productCardHTML(p)).join('');
}

function productCardHTML(p) {
  if (p.plans) {
    const plans = p.plans.map((pl, i) => {
      const kc = p.keys?.[i]?.length || 0;
      return `<div class="plan-row">
        <div class="plan-days">📅 ${pl.days} Day${pl.days>1?'s':''}</div>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="plan-price">₹${pl.price}</div>
          <div class="plan-stock ${kc>0?'in-stock':'out-stock'}">${kc>0?'✅ '+kc+' left':'❌ Out'}</div>
        </div>
      </div>`;
    }).join('');
    return `<div class="product-card">
      <div class="product-header"><div class="product-name">📦 ${p.name}</div></div>
      <div class="product-desc">${p.desc}</div>
      <div class="plans-grid">${plans}</div>
    </div>`;
  } else {
    const kc = p.keys?.length || 0;
    return `<div class="product-card">
      <div class="product-header">
        <div class="product-name">📦 ${p.name}</div>
        <div class="plan-price">₹${p.price}</div>
      </div>
      <div class="product-desc">${p.desc}</div>
      <div class="plan-stock ${kc>0?'in-stock':'out-stock'}">${kc>0?'✅ '+kc+' in stock':'❌ Out of Stock'}</div>
    </div>`;
  }
}

// ── ORDERS ────────────────────────────────────────────────────
async function loadOrders() {
  const data = await api('get_orders');
  if (!data.ok) return;
  const orders = data.orders || [];
  if (!orders.length) {
    document.getElementById('orders-content').innerHTML = `
      <div class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">No Orders Yet</div><div class="empty-sub">Go to Shop and buy something!</div></div>`;
    return;
  }
  document.getElementById('orders-content').innerHTML = orders.map(o => orderCardHTML(o)).join('');
}

function orderCardHTML(o) {
  const date = o.date ? o.date.split(' ')[0] : '';
  return `<div class="order-card">
    <div class="order-header">
      <div class="order-id">${o.order_id}</div>
      <div class="order-date">${date}</div>
    </div>
    <div class="order-product">${o.product}</div>
    <div class="order-plan">🗓 ${o.plan}</div>
    <div class="key-box" onclick="copyKey('${o.key}', this)">🔑 ${o.key}</div>
    <div class="key-copy-hint">tap to copy</div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">
      <div class="order-price">₹${o.price}</div>
      <div style="font-size:11px;color:var(--muted)">UTR: ${o.utr || '—'}</div>
    </div>
  </div>`;
}

function copyKey(key, el) {
  navigator.clipboard?.writeText(key).then(() => {
    el.style.borderColor = 'var(--green)';
    el.style.color = 'var(--green)';
    toast('🔑 Key Copied!');
    setTimeout(() => { el.style.borderColor=''; el.style.color=''; }, 1500);
  });
}

// ── PROFILE ───────────────────────────────────────────────────
async function loadProfile() {
  const data = await api('get_profile');
  if (!data.ok) return;
  const u = data.user;
  if (!u) { document.getElementById('profile-content').innerHTML = `<div class="empty-state"><div class="empty-icon">👤</div><div class="empty-text">Not found</div></div>`; return; }

  const initial = (u.name||'U')[0].toUpperCase();
  document.getElementById('profile-content').innerHTML = `
    <div class="profile-avatar">${initial}</div>
    <div class="profile-name">${u.name}</div>
    <div class="profile-handle">${u.username ? '@'+u.username : 'ID: '+u.id}</div>
    <div class="profile-stats">
      <div class="stat-box">
        <div class="stat-val">${data.order_count}</div>
        <div class="stat-lbl">Orders</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">₹${data.total_spent}</div>
        <div class="stat-lbl">Spent</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">${u.ref_points||0}</div>
        <div class="stat-lbl">Points</div>
      </div>
    </div>
    <div class="card">
      <div class="info-row">
        <div class="info-lbl">📱 Phone</div>
        <div class="info-val">
          ${u.phone_verified
            ? `<span class="badge-verified">✅ ${u.phone}</span>`
            : `<span class="badge-unverified">❌ Not Verified</span>`}
        </div>
      </div>
      <div class="info-row">
        <div class="info-lbl">🆔 User ID</div>
        <div class="info-val" style="font-family:var(--mono);font-size:12px">${u.id}</div>
      </div>
      <div class="info-row">
        <div class="info-lbl">📅 Joined</div>
        <div class="info-val">${(u.joined||'').split(' ')[0]}</div>
      </div>
      <div class="info-row">
        <div class="info-lbl">👥 Referred</div>
        <div class="info-val">${u.ref_count||0} users</div>
      </div>
      ${data.is_owner ? `<div class="info-row"><div class="info-lbl">🔑 Role</div><div class="info-val"><span class="badge-verified">👑 Owner</span></div></div>` : ''}
    </div>
  `;
}

// ── ADMIN ─────────────────────────────────────────────────────
let adminTab = 'stats';
async function loadAdmin() {
  document.getElementById('admin-content').innerHTML = `
    <div class="admin-tabs">
      <div class="admin-tab ${adminTab==='stats'?'active':''}" onclick="switchAdminTab('stats')">📊 Stats</div>
      <div class="admin-tab ${adminTab==='pending'?'active':''}" onclick="switchAdminTab('pending')">⏳ Pending</div>
      <div class="admin-tab ${adminTab==='orders'?'active':''}" onclick="switchAdminTab('orders')">✅ Orders</div>
      <div class="admin-tab ${adminTab==='users'?'active':''}" onclick="switchAdminTab('users')">👥 Users</div>
    </div>
    <div id="admin-tab-content"></div>
  `;
  loadAdminTab(adminTab);
}

function switchAdminTab(tab) {
  adminTab = tab;
  document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');
  loadAdminTab(tab);
}

async function loadAdminTab(tab) {
  const el = document.getElementById('admin-tab-content');
  el.innerHTML = `<div class="shimmer shimmer-line" style="height:80px;margin-bottom:10px"></div>`;

  if (tab === 'stats') {
    const d = await api('get_stats');
    if (!d.ok) return;
    el.innerHTML = `
      <div class="stats-grid">
        <div class="stat-card revenue"><div class="stat-card-val">₹${d.revenue}</div><div class="stat-card-lbl">Revenue</div></div>
        <div class="stat-card users"><div class="stat-card-val">${d.users}</div><div class="stat-card-lbl">Users</div></div>
        <div class="stat-card orders"><div class="stat-card-val">${d.orders}</div><div class="stat-card-lbl">Orders</div></div>
        <div class="stat-card pending"><div class="stat-card-val">${d.pending}</div><div class="stat-card-lbl">Pending</div></div>
        <div class="stat-card products"><div class="stat-card-val">${d.products}</div><div class="stat-card-lbl">Products</div></div>
        <div class="stat-card keys"><div class="stat-card-val">${d.keys}</div><div class="stat-card-lbl">Keys Left</div></div>
      </div>`;
  }

  else if (tab === 'pending') {
    const d = await api('get_pending');
    if (!d.ok) return;
    if (!d.pending.length) {
      el.innerHTML = `<div class="empty-state"><div class="empty-icon">✅</div><div class="empty-text">No Pending Payments</div></div>`;
      return;
    }
    el.innerHTML = d.pending.map(p => `
      <div class="pending-card">
        <div class="pending-header">
          <div class="pending-user">👤 ${p.buyer_name}${p.buyer_user?' @'+p.buyer_user:''}</div>
          <div class="pending-date">${(p.date||'').split(' ')[0]}</div>
        </div>
        <div class="pending-product">📦 ${p.product} — ${p.plan}</div>
        <div class="pending-utr">🔢 UTR: ${p.utr} &nbsp;|&nbsp; 📛 ${p.pay_name}</div>
        <div class="pending-price">₹${p.price}</div>
        <div class="pending-actions">
          <button class="btn btn-success btn-sm" onclick="toast('✅ Use bot to approve: /start')">✅ Approve</button>
          <button class="btn btn-danger btn-sm" onclick="toast('❌ Use bot to reject: /start')">❌ Reject</button>
        </div>
      </div>`).join('');
  }

  else if (tab === 'orders') {
    const d = await api('get_all_orders');
    if (!d.ok) return;
    if (!d.orders.length) {
      el.innerHTML = `<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">No Orders Yet</div></div>`;
      return;
    }
    el.innerHTML = d.orders.slice(0,30).map(o => `
      <div class="order-card">
        <div class="order-header"><div class="order-id">${o.order_id}</div><div class="order-date">${(o.date||'').split(' ')[0]}</div></div>
        <div class="order-product">${o.product} — ${o.plan}</div>
        <div class="key-box" onclick="copyKey('${o.key}',this)">🔑 ${o.key}</div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">
          <div class="order-price">₹${o.price}</div>
          <div style="font-size:11px;color:var(--muted)">UTR: ${o.utr||'—'}</div>
        </div>
      </div>`).join('');
  }

  else if (tab === 'users') {
    const d = await api('get_all_users');
    if (!d.ok) return;
    if (!d.users.length) {
      el.innerHTML = `<div class="empty-state"><div class="empty-icon">👥</div><div class="empty-text">No Users Yet</div></div>`;
      return;
    }
    el.innerHTML = `<div class="card">${d.users.map(u => `
      <div class="user-row">
        <div class="user-avatar">${(u.name||'U')[0].toUpperCase()}</div>
        <div class="user-info">
          <div class="user-name">${u.name}${u.username?' @'+u.username:''}</div>
          <div class="user-meta">${u.verified?'📱✅':'📱❌'} &nbsp;|&nbsp; Joined ${(u.joined||'').split(' ')[0]}</div>
        </div>
        <div class="user-orders">${u.orders} orders</div>
      </div>`).join('')}</div>`;
  }
}

// ── INIT ──────────────────────────────────────────────────────
async function init() {
  try {
    const data = await api('get_home');
    if (data.ok) {
      isOwner = data.is_owner;
      if (isOwner) {
        document.getElementById('nav-admin').style.display = '';
        document.getElementById('header-right').innerHTML = '<div class="header-badge">ADMIN</div>';
      }
    }
  } catch(e) {}

  document.getElementById('loader').style.display = 'none';
  document.getElementById('app').style.display = 'flex';
  loadPage('home');
}

init();
</script>
</body>
</html>
