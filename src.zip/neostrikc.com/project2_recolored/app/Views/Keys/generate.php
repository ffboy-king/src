<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
:root {
    --cyan:    #7c3aed;
    --magenta: #f97316;
    --gold:    #c0c0c0;
    --dark:    #0a0a0f;
    --card-bg: rgba(15, 5, 30, 0.85);
    --border:  rgba(124, 58, 237, 0.18);
}

body {
    background: var(--dark) !important;
    font-family: 'Rajdhani', sans-serif;
    min-height: 100vh;
}

.gen-wrap {
    max-width: 520px;
    margin: 0 auto;
    padding: 1.5rem 1rem 3rem;
}

/* ── CYBER CARD ── */
.cyber-card {
    background: var(--card-bg);
    border: 1px solid var(--border);
    border-radius: 16px;
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    box-shadow: 0 0 0 1px rgba(0,245,255,0.04), 0 0 30px rgba(0,245,255,0.06), 0 8px 40px rgba(0,0,0,0.6);
    position: relative;
    overflow: hidden;
    margin-bottom: 1.25rem;
}

.cyber-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,245,255,0.012) 2px, rgba(0,245,255,0.012) 4px);
    pointer-events: none;
    z-index: 0;
}

.cyber-card::after {
    content: '';
    position: absolute;
    top: -1px; left: -1px;
    width: 28px; height: 28px;
    border-top: 2px solid var(--cyan);
    border-left: 2px solid var(--cyan);
    border-radius: 16px 0 0 0;
    pointer-events: none;
}

.cyber-card-inner {
    position: relative;
    z-index: 1;
    padding: 1.4rem;
}

/* ── CARD HEAD ── */
.cyber-card-head {
    position: relative;
    z-index: 1;
    padding: 1.1rem 1.4rem;
    border-bottom: 1px solid rgba(0,245,255,0.12);
    background: rgba(0,245,255,0.03);
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.cyber-card-head-icon {
    width: 36px; height: 36px;
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    background: rgba(0,245,255,0.08);
    border: 1px solid rgba(0,245,255,0.25);
    color: var(--cyan);
    flex-shrink: 0;
}

.cyber-card-head-icon svg { width: 18px; height: 18px; }

.cyber-card-title {
    font-family: 'Orbitron', monospace;
    font-size: 0.8rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    background: linear-gradient(90deg, var(--cyan), var(--magenta));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.cyber-card-sub {
    font-size: 0.72rem;
    color: rgba(255,255,255,0.35);
    letter-spacing: 0.5px;
    margin-top: 2px;
}

.cyber-head-bg {
    position: absolute;
    right: -10px; top: -8px;
    font-size: 80px;
    color: rgba(0,245,255,0.04);
    transform: rotate(-10deg);
    line-height: 1;
    pointer-events: none;
}

/* ── FORM ── */
.cyber-label {
    display: block;
    font-family: 'Rajdhani', sans-serif;
    font-size: 0.68rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: rgba(0,245,255,0.65);
    margin-bottom: 0.4rem;
}

.cyber-input-group {
    display: flex;
    align-items: center;
    background: rgba(0,0,20,0.6);
    border: 1px solid rgba(0,245,255,0.2);
    border-radius: 10px;
    overflow: hidden;
    transition: border-color 0.25s, box-shadow 0.25s;
}

.cyber-input-group:focus-within {
    border-color: rgba(0,245,255,0.6);
    box-shadow: 0 0 14px rgba(0,245,255,0.15);
}

.cyber-input-icon {
    padding: 0 0.75rem;
    color: rgba(0,245,255,0.5);
    flex-shrink: 0;
    display: flex; align-items: center;
}

.cyber-input-icon svg { width: 16px; height: 16px; }

.cyber-input-group input,
.cyber-input-group select {
    flex: 1;
    background: transparent !important;
    border: none !important;
    outline: none !important;
    box-shadow: none !important;
    color: rgba(255,255,255,0.85) !important;
    font-family: 'Rajdhani', sans-serif;
    font-weight: 600;
    font-size: 0.95rem;
    padding: 0.6rem 0.5rem 0.6rem 0;
}

.cyber-input-group select option { background: #050520; color: #fff; }

.cyber-input-suffix {
    padding: 0 0.75rem;
    font-size: 0.65rem;
    font-weight: 700;
    letter-spacing: 1px;
    color: rgba(0,245,255,0.4);
    border-left: 1px solid rgba(0,245,255,0.1);
    flex-shrink: 0;
}

.cyber-hint {
    font-size: 0.7rem;
    color: rgba(255,255,255,0.28);
    letter-spacing: 0.4px;
    margin-top: 0.3rem;
}

.cyber-row {
    display: grid;
    grid-template-columns: 1fr;
    gap: 0.75rem;
}

@media (min-width: 400px) {
    .cyber-row { grid-template-columns: 1fr 1fr; }
}

.cyber-field { margin-bottom: 1rem; }

/* ── COST BOX ── */
.cyber-cost-box {
    background: rgba(0,0,20,0.7);
    border: 1px solid rgba(0,245,255,0.15);
    border-radius: 12px;
    padding: 0.9rem 1.1rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
}

.cyber-cost-label {
    font-size: 0.62rem;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: rgba(255,255,255,0.3);
    margin-bottom: 0.2rem;
}

.cyber-cost-amount {
    font-family: 'Orbitron', monospace;
    font-size: 1.6rem;
    font-weight: 900;
    background: linear-gradient(90deg, var(--cyan), var(--magenta), var(--gold));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1;
}

.cyber-cost-breakdown {
    font-size: 0.68rem;
    color: rgba(0,245,255,0.45);
    margin-top: 0.15rem;
}

.cyber-cost-icon { color: rgba(255,215,0,0.4); flex-shrink: 0; }
.cyber-cost-icon svg { width: 28px; height: 28px; }

/* ── GENERATE BUTTON ── */
.cyber-btn-generate {
    width: 100%;
    padding: 0.85rem;
    border-radius: 12px;
    border: 1px solid rgba(0,245,255,0.4);
    background: linear-gradient(135deg, rgba(0,245,255,0.12), rgba(255,0,200,0.08));
    color: #fff;
    font-family: 'Orbitron', monospace;
    font-size: 0.82rem;
    font-weight: 700;
    letter-spacing: 2px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    transition: all 0.25s ease;
    box-shadow: 0 0 20px rgba(0,245,255,0.08);
}

.cyber-btn-generate:hover {
    background: linear-gradient(135deg, rgba(0,245,255,0.22), rgba(255,0,200,0.15));
    border-color: var(--cyan);
    box-shadow: 0 0 28px rgba(0,245,255,0.22);
    transform: translateY(-1px);
    color: var(--cyan);
}

.cyber-btn-generate svg { width: 17px; height: 17px; }

/* ── BACK LINK ── */
.cyber-back-link {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.4rem;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: rgba(255,255,255,0.28);
    text-decoration: none;
    margin-top: 1.25rem;
    transition: color 0.2s;
}

.cyber-back-link:hover { color: var(--cyan); }
.cyber-back-link svg { width: 14px; height: 14px; }

/* ══ RESULT CARDS ══ */
.cyber-result-head {
    position: relative;
    z-index: 1;
    padding: 0.9rem 1.2rem;
    border-bottom: 1px solid rgba(0,245,255,0.12);
    display: flex;
    align-items: center;
    gap: 0.6rem;
    background: linear-gradient(90deg, rgba(0,245,255,0.05), rgba(255,0,200,0.03));
}

.cyber-result-title {
    font-family: 'Orbitron', monospace;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 2px;
    color: var(--gold);
}

.cyber-result-count {
    margin-left: auto;
    font-family: 'Orbitron', monospace;
    font-size: 0.68rem;
    color: var(--cyan);
    background: rgba(0,245,255,0.08);
    border: 1px solid rgba(0,245,255,0.2);
    border-radius: 20px;
    padding: 0.15rem 0.6rem;
}

.cyber-badges {
    display: flex;
    flex-wrap: wrap;
    gap: 0.4rem;
    padding: 0.75rem 1.1rem;
    border-bottom: 1px solid rgba(0,245,255,0.07);
    position: relative;
    z-index: 1;
}

.cyber-badge {
    font-family: 'Rajdhani', sans-serif;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.4px;
    padding: 0.2rem 0.6rem;
    border-radius: 6px;
    display: flex;
    align-items: center;
    gap: 0.3rem;
}

.badge-gold    { background: rgba(255,215,0,0.12);   color: var(--gold);    border: 1px solid rgba(255,215,0,0.28); }
.badge-cyan    { background: rgba(0,245,255,0.1);    color: var(--cyan);    border: 1px solid rgba(0,245,255,0.22); }
.badge-magenta { background: rgba(255,0,200,0.1);    color: var(--magenta); border: 1px solid rgba(255,0,200,0.22); }

.cyber-keys-list {
    position: relative;
    z-index: 1;
    max-height: 280px;
    overflow-y: auto;
    padding: 0.75rem;
}

.cyber-keys-list::-webkit-scrollbar { width: 4px; }
.cyber-keys-list::-webkit-scrollbar-track { background: transparent; }
.cyber-keys-list::-webkit-scrollbar-thumb { background: rgba(0,245,255,0.3); border-radius: 4px; }

.cyber-key-row {
    display: flex;
    align-items: center;
    padding: 0.48rem 0.7rem;
    border-radius: 8px;
    background: rgba(0,0,20,0.5);
    border: 1px solid rgba(0,245,255,0.08);
    margin-bottom: 0.4rem;
    transition: border-color 0.2s, background 0.2s;
}

.cyber-key-row:hover { background: rgba(0,245,255,0.05); border-color: rgba(0,245,255,0.2); }

.cyber-key-num {
    font-size: 0.62rem;
    color: rgba(255,255,255,0.22);
    min-width: 20px;
    font-family: 'Orbitron', monospace;
}

.cyber-key-text {
    font-family: 'Orbitron', monospace;
    font-size: 0.78rem;
    font-weight: 700;
    color: var(--cyan);
    letter-spacing: 1px;
    text-shadow: 0 0 8px rgba(0,245,255,0.3);
    flex: 1;
    padding: 0 0.5rem;
    word-break: break-all;
}

.cyber-copy-btn {
    width: 28px; height: 28px;
    border-radius: 6px;
    border: 1px solid rgba(0,245,255,0.2);
    background: transparent;
    color: rgba(0,245,255,0.5);
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
    flex-shrink: 0;
}

.cyber-copy-btn svg { width: 13px; height: 13px; }
.cyber-copy-btn:hover { background: rgba(0,245,255,0.1); border-color: var(--cyan); color: var(--cyan); box-shadow: 0 0 8px rgba(0,245,255,0.2); }
.cyber-copy-btn.copied { background: rgba(0,255,150,0.15); border-color: #00ff96; color: #00ff96; }

.cyber-action-row {
    position: relative;
    z-index: 1;
    display: flex;
    gap: 0.6rem;
    padding: 0.75rem 1rem;
    border-top: 1px solid rgba(0,245,255,0.1);
}

.cyber-btn-action {
    flex: 1;
    padding: 0.6rem;
    border-radius: 10px;
    border: 1px solid rgba(0,245,255,0.25);
    background: rgba(0,245,255,0.06);
    color: var(--cyan);
    font-family: 'Rajdhani', sans-serif;
    font-weight: 700;
    font-size: 0.78rem;
    letter-spacing: 1px;
    text-transform: uppercase;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 0.4rem;
    transition: all 0.2s;
}

.cyber-btn-action svg { width: 15px; height: 15px; }
.cyber-btn-action:hover { background: rgba(0,245,255,0.13); border-color: var(--cyan); box-shadow: 0 0 12px rgba(0,245,255,0.15); }

.cyber-btn-dl {
    flex: 0 0 44px;
    border-color: rgba(255,215,0,0.25);
    background: rgba(255,215,0,0.05);
    color: var(--gold);
}

.cyber-btn-dl:hover { background: rgba(255,215,0,0.12); border-color: var(--gold); box-shadow: 0 0 12px rgba(255,215,0,0.15); }

.cyber-single-key-box {
    text-align: center;
    padding: 1.2rem;
    border: 1px dashed rgba(0,245,255,0.25);
    border-radius: 12px;
    background: rgba(0,245,255,0.03);
    margin-bottom: 1rem;
}

.cyber-single-key-label {
    font-size: 0.62rem;
    letter-spacing: 3px;
    text-transform: uppercase;
    color: rgba(255,255,255,0.3);
    margin-bottom: 0.5rem;
}

.cyber-single-key-value {
    font-family: 'Orbitron', monospace;
    font-size: 1.1rem;
    font-weight: 900;
    color: var(--cyan);
    text-shadow: 0 0 16px rgba(0,245,255,0.4);
    letter-spacing: 2px;
    word-break: break-all;
}

/* ── ANIMATION ── */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}

.anim-up { animation: fadeInUp 0.5s ease both; }
.d1 { animation-delay: 0.05s; }
.d2 { animation-delay: 0.12s; }
</style>

<div class="gen-wrap">

    <?= $this->include('Layout/msgStatus') ?>

    <?php if (session()->getFlashdata('bulk_keys')) : ?>
        <?php $bulkKeys = session()->getFlashdata('bulk_keys'); ?>
        <div class="cyber-card anim-up d1">
            <div class="cyber-result-head">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:18px;height:18px;color:var(--gold);flex-shrink:0;">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                </svg>
                <span class="cyber-result-title">VIP LICENSE ISSUED</span>
                <span class="cyber-result-count"><?= count($bulkKeys) ?> KEYS</span>
            </div>

            <div class="cyber-badges">
                <span class="cyber-badge badge-gold"><?= session()->getFlashdata('game') ?></span>
                <span class="cyber-badge badge-cyan"><?= session()->getFlashdata('duration') ?> Days</span>
                <span class="cyber-badge badge-magenta"><?= session()->getFlashdata('max_devices') ?> Device(s)</span>
            </div>

            <div class="cyber-keys-list" id="bulkKeysBox">
                <?php foreach ($bulkKeys as $index => $key) : ?>
                    <div class="cyber-key-row" data-key="<?= esc($key) ?>">
                        <span class="cyber-key-num"><?= $index + 1 ?></span>
                        <span class="cyber-key-text"><?= esc($key) ?></span>
                        <button class="cyber-copy-btn" onclick="copySingleKey(this, '<?= esc($key) ?>')">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                            </svg>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="cyber-action-row">
                <button class="cyber-btn-action" onclick="copyAllKeys()">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>
                    </svg>
                    Copy All Keys
                </button>
                <button class="cyber-btn-action cyber-btn-dl" onclick="downloadKeys()" title="Download TXT">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                    </svg>
                </button>
            </div>
        </div>

    <?php elseif (session()->getFlashdata('user_key')) : ?>
        <div class="cyber-card anim-up d1">
            <div class="cyber-result-head">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:18px;height:18px;color:var(--gold);flex-shrink:0;">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                </svg>
                <span class="cyber-result-title">VIP LICENSE ISSUED</span>
            </div>
            <div class="cyber-badges">
                <span class="cyber-badge badge-gold"><?= session()->getFlashdata('game') ?></span>
                <span class="cyber-badge badge-cyan"><?= session()->getFlashdata('duration') ?> Days</span>
                <span class="cyber-badge badge-magenta"><?= session()->getFlashdata('max_devices') ?> Device(s)</span>
            </div>
            <div class="cyber-card-inner" style="padding-top:1rem;">
                <div class="cyber-single-key-box">
                    <div class="cyber-single-key-label">License Key</div>
                    <div class="cyber-single-key-value"><?= session()->getFlashdata('user_key') ?></div>
                    <input type="hidden" id="licenseKey" value="<?= session()->getFlashdata('user_key') ?>">
                </div>
                <button class="cyber-btn-generate" onclick="copyLicense()">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>
                    </svg>
                    <span>Copy License</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <div class="cyber-card anim-up d2">
        <div class="cyber-card-head">
            <div class="cyber-card-head-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M13 10V3L4 14h7v7l9-11h-7z"/>
                </svg>
            </div>
            <div>
                <div class="cyber-card-title">Generate Key</div>
                <div class="cyber-card-sub">Create single or bulk access licenses</div>
            </div>
            <div class="cyber-head-bg"><i class="bi bi-cpu-fill"></i></div>
        </div>

        <div class="cyber-card-inner">
            <?= form_open() ?>

            <div class="cyber-field">
                <label class="cyber-label">Select Game Engine</label>
                <div class="cyber-input-group">
                    <span class="cyber-input-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"/>
                        </svg>
                    </span>
                    <?= form_dropdown(['name' => 'game', 'id' => 'game'], $game, old('game') ?: '') ?>
                </div>
            </div>

            <div class="cyber-row">
                <div class="cyber-field">
                    <label class="cyber-label">Hardware Limit</label>
                    <div class="cyber-input-group">
                        <span class="cyber-input-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 18h.01M8 21h8a2 2 0 002-2v-7a2 2 0 00-2-2H8a2 2 0 00-2 2v7a2 2 0 002 2z"/>
                            </svg>
                        </span>
                        <input type="number" name="max_devices" id="max_devices"
                               value="<?= old('max_devices') ?: 1 ?>" min="1">
                    </div>
                </div>
                <div class="cyber-field">
                    <label class="cyber-label">Validity</label>
                    <div class="cyber-input-group">
                        <span class="cyber-input-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </span>
                        <?= form_dropdown(['name' => 'duration', 'id' => 'duration'], $duration, old('duration') ?: '') ?>
                    </div>
                </div>
            </div>

            <div class="cyber-field">
                <label class="cyber-label">Quantity (Bulk Keys)</label>
                <div class="cyber-input-group">
                    <span class="cyber-input-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"/>
                        </svg>
                    </span>
                    <input type="number" name="loopcount" id="loopcount"
                           value="<?= old('loopcount') ?: 1 ?>"
                           min="1" max="100" placeholder="1 – 100">
                    <span class="cyber-input-suffix">MAX 100</span>
                </div>
                <div class="cyber-hint">Enter more than 1 to generate bulk keys at once.</div>
            </div>

            <div class="cyber-cost-box">
                <div>
                    <div class="cyber-cost-label">Cost Estimation</div>
                    <div class="cyber-cost-amount">₹<span id="estimation">0.00</span></div>
                    <div class="cyber-cost-breakdown" id="estimationBreakdown"></div>
                </div>
                <div class="cyber-cost-icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>
                    </svg>
                </div>
            </div>

            <button type="submit" class="cyber-btn-generate">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M13 10V3L4 14h7v7l9-11h-7z"/>
                </svg>
                <span id="generateBtnText">GENERATE NOW</span>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                </svg>
            </button>

            <?= form_close() ?>
        </div>
    </div>

    <a href="<?= site_url('keys') ?>" class="cyber-back-link">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
        </svg>
        View All Active Keys
    </a>

</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    function copySingleKey(btn, key) {
        navigator.clipboard.writeText(key).then(() => {
            btn.classList.add('copied');
            btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:13px;height:13px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>';
            setTimeout(() => {
                btn.classList.remove('copied');
                btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:13px;height:13px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>';
            }, 1500);
        });
    }

    function copyAllKeys() {
        var rows = document.querySelectorAll('#bulkKeysBox .cyber-key-row');
        var keys = [];
        rows.forEach(row => keys.push(row.getAttribute('data-key')));
        navigator.clipboard.writeText(keys.join('\n')).then(() => {
            alert('All ' + keys.length + ' keys copied!');
        });
    }

    function downloadKeys() {
        var rows = document.querySelectorAll('#bulkKeysBox .cyber-key-row');
        var keys = [];
        rows.forEach(row => keys.push(row.getAttribute('data-key')));
        var blob = new Blob([keys.join('\n')], { type: 'text/plain' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'keys_' + Date.now() + '.txt';
        a.click();
    }

    function copyLicense() {
        var val = document.getElementById("licenseKey").value;
        navigator.clipboard.writeText(val).then(() => {
            alert("VIP Key Copied!");
        });
    }

    $(document).ready(function() {
        var priceData = JSON.parse('<?= $price ?>');

        function updatePrice() {
            var devices     = parseInt($("#max_devices").val()) || 1;
            var quantity    = parseInt($("#loopcount").val())   || 1;
            var durationKey = $("#duration").val();
            var gPrice      = priceData[durationKey] || 0;

            if (gPrice > 0) {
                var perKey = gPrice * devices;
                var total  = perKey * quantity;
                $("#estimation").text(total.toFixed(2));
                if (quantity > 1) {
                    $("#estimationBreakdown").text('₹' + perKey.toFixed(2) + ' × ' + quantity + ' keys');
                } else if (devices > 1) {
                    $("#estimationBreakdown").text('₹' + gPrice.toFixed(2) + ' × ' + devices + ' devices');
                } else {
                    $("#estimationBreakdown").text('');
                }
            } else {
                $("#estimation").text('0.00');
                $("#estimationBreakdown").text('');
            }

            var qty = parseInt($("#loopcount").val()) || 1;
            $("#generateBtnText").text(qty > 1 ? 'GENERATE ' + qty + ' KEYS' : 'GENERATE NOW');
        }

        $("#max_devices, #duration, #loopcount").on('input change', updatePrice);
        updatePrice();
    });
</script>
<?= $this->endSection() ?>
