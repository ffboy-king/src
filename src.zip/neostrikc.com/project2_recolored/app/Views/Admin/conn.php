<?php

$servername = "localhost";
$username = "neostrik_Pro";
$password = "neostrik_Pro";
$dbname = "neostrik_Pro";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>